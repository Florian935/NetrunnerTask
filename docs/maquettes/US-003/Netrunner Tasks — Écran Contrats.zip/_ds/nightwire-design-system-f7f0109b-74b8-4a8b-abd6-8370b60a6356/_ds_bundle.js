/* @ds-bundle: {"format":4,"namespace":"NightwireDesignSystem_f7f010","components":[{"name":"Avatar","sourcePath":"components/core/Avatar.jsx"},{"name":"Icon","sourcePath":"components/core/Icon.jsx"},{"name":"Alert","sourcePath":"components/feedback/Alert.jsx"},{"name":"Badge","sourcePath":"components/feedback/Badge.jsx"},{"name":"ProgressBar","sourcePath":"components/feedback/ProgressBar.jsx"},{"name":"Tag","sourcePath":"components/feedback/Tag.jsx"},{"name":"Toast","sourcePath":"components/feedback/Toast.jsx"},{"name":"Tooltip","sourcePath":"components/feedback/Tooltip.jsx"},{"name":"Button","sourcePath":"components/forms/Button.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"IconButton","sourcePath":"components/forms/IconButton.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Radio","sourcePath":"components/forms/Radio.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Slider","sourcePath":"components/forms/Slider.jsx"},{"name":"Switch","sourcePath":"components/forms/Switch.jsx"},{"name":"Breadcrumbs","sourcePath":"components/navigation/Breadcrumbs.jsx"},{"name":"CommandPalette","sourcePath":"components/navigation/CommandPalette.jsx"},{"name":"Pagination","sourcePath":"components/navigation/Pagination.jsx"},{"name":"Tabs","sourcePath":"components/navigation/Tabs.jsx"},{"name":"Card","sourcePath":"components/surfaces/Card.jsx"},{"name":"DataTable","sourcePath":"components/surfaces/DataTable.jsx"},{"name":"HudPanel","sourcePath":"components/surfaces/HudPanel.jsx"},{"name":"StatCard","sourcePath":"components/surfaces/StatCard.jsx"}],"sourceHashes":{"components/core/Avatar.jsx":"614458ef91b1","components/core/Icon.jsx":"bcd643948e93","components/feedback/Alert.jsx":"084de63e7da4","components/feedback/Badge.jsx":"4cedf40b0598","components/feedback/ProgressBar.jsx":"51ee70e67544","components/feedback/Tag.jsx":"acb5fb6217b5","components/feedback/Toast.jsx":"c03ca0ad3ada","components/feedback/Tooltip.jsx":"f0fafc3b0a93","components/forms/Button.jsx":"8e8c47275e12","components/forms/Checkbox.jsx":"8b716b35ee46","components/forms/IconButton.jsx":"11bd198c2463","components/forms/Input.jsx":"99cce35b2816","components/forms/Radio.jsx":"1765514a74a1","components/forms/Select.jsx":"b4160195d3c4","components/forms/Slider.jsx":"a363280e7f55","components/forms/Switch.jsx":"ac291ef7caf8","components/navigation/Breadcrumbs.jsx":"2bea80f0a953","components/navigation/CommandPalette.jsx":"f25372d99aee","components/navigation/Pagination.jsx":"0d8ad5f7f649","components/navigation/Tabs.jsx":"622e147a73a9","components/surfaces/Card.jsx":"daa658b66de8","components/surfaces/DataTable.jsx":"6dc8f5aef70c","components/surfaces/HudPanel.jsx":"2328632b4a66","components/surfaces/StatCard.jsx":"b14cbce4db7f","ui_kits/marketing/landing.jsx":"c2d53e4988f3","ui_kits/netrunner-console/app.jsx":"d8b2556a7358","ui_kits/netrunner-console/charts.jsx":"07efb0ed4eb2"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.NightwireDesignSystem_f7f010 = window.NightwireDesignSystem_f7f010 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Avatar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const TONES = {
  cyan: 'var(--cyan-500)',
  magenta: 'var(--magenta-500)',
  mint: 'var(--mint-500)',
  violet: 'var(--violet-500)',
  amber: 'var(--amber-500)',
  red: 'var(--red-500)'
};
const STATUS = {
  online: 'var(--mint-500)',
  busy: 'var(--amber-500)',
  away: 'var(--violet-500)',
  offline: 'var(--steel-600)'
};
function initials(name = '') {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (!parts.length) return '?';
  return (parts[0][0] + (parts[1] ? parts[1][0] : '')).toUpperCase();
}

/**
 * NIGHTWIRE Avatar — beveled operator chip. Image or initials, neon ring,
 * optional live-status dot.
 */
function Avatar({
  src,
  name = '',
  size = 40,
  accent = 'cyan',
  status,
  ring = true,
  square = true,
  style = {},
  ...rest
}) {
  const c = TONES[accent] || TONES.cyan;
  const radius = square ? 'var(--radius-sm)' : '999px';
  const clip = square ? 'var(--clip-bevel-sm)' : 'none';
  const fs = Math.round(size * 0.4);
  const dot = Math.max(8, Math.round(size * 0.26));
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      position: 'relative',
      display: 'inline-flex',
      width: size,
      height: size,
      flexShrink: 0,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      width: size,
      height: size,
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      overflow: 'hidden',
      borderRadius: radius,
      clipPath: clip,
      background: src ? 'var(--bg-surface)' : `color-mix(in srgb, ${c} 16%, var(--bg-surface))`,
      border: ring ? `1px solid ${c}` : '1px solid var(--border)',
      boxShadow: ring ? `0 0 10px -2px ${c}` : 'none',
      color: c,
      fontFamily: 'var(--font-display)',
      fontWeight: 'var(--weight-bold)',
      fontSize: fs,
      letterSpacing: '.04em',
      userSelect: 'none'
    }
  }, src ? /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: name,
    style: {
      width: '100%',
      height: '100%',
      objectFit: 'cover'
    }
  }) : initials(name)), status && /*#__PURE__*/React.createElement("span", {
    title: status,
    style: {
      position: 'absolute',
      right: -2,
      bottom: -2,
      width: dot,
      height: dot,
      borderRadius: '999px',
      background: STATUS[status] || STATUS.offline,
      border: '2px solid var(--bg-app)',
      boxShadow: status === 'online' ? `0 0 6px ${STATUS.online}` : 'none'
    }
  }));
}
Object.assign(__ds_scope, { Avatar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Avatar.jsx", error: String((e && e.message) || e) }); }

// components/core/Icon.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const {
  useRef,
  useEffect
} = React;
/**
 * NIGHTWIRE Icon — thin wrapper around Lucide line icons.
 * Requires the Lucide UMD script loaded on the page (window.lucide).
 * Renders imperatively into a span React leaves empty, so there is no
 * React/DOM conflict when Lucide swaps the <i> for an <svg>.
 */
function Icon({
  name,
  size = 18,
  strokeWidth = 2,
  color = 'currentColor',
  style = {},
  ...rest
}) {
  const ref = useRef(null);
  useEffect(() => {
    const el = ref.current;
    if (!el || !window.lucide) return;
    el.innerHTML = '';
    const i = document.createElement('i');
    i.setAttribute('data-lucide', name);
    el.appendChild(i);
    window.lucide.createIcons({
      nameAttr: 'data-lucide',
      attrs: {
        width: size,
        height: size,
        'stroke-width': strokeWidth
      }
    });
  }, [name, size, strokeWidth]);
  return /*#__PURE__*/React.createElement("span", _extends({
    ref: ref,
    "aria-hidden": "true",
    style: {
      display: 'inline-flex',
      color,
      lineHeight: 0,
      ...style
    }
  }, rest));
}
Object.assign(__ds_scope, { Icon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Icon.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Alert.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const KIND = {
  success: {
    c: 'var(--mint-500)',
    icon: 'check-circle',
    g: 'var(--glow-mint)'
  },
  warning: {
    c: 'var(--amber-500)',
    icon: 'alert-triangle',
    g: '0 0 14px rgba(255,176,32,.3)'
  },
  danger: {
    c: 'var(--red-500)',
    icon: 'shield-alert',
    g: 'var(--glow-danger)'
  },
  info: {
    c: 'var(--cyan-500)',
    icon: 'info',
    g: 'var(--glow-cyan)'
  }
};

/**
 * NIGHTWIRE Alert — inline status banner with a left neon rail + HUD hatch.
 */
function Alert({
  kind = 'info',
  title,
  children,
  onClose,
  style = {},
  ...rest
}) {
  const k = KIND[kind] || KIND.info;
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "alert",
    style: {
      position: 'relative',
      display: 'flex',
      gap: 'var(--space-3)',
      padding: 'var(--space-3) var(--space-4)',
      paddingLeft: 'var(--space-4)',
      background: `color-mix(in srgb, ${k.c} 8%, var(--bg-panel))`,
      borderLeft: `2px solid ${k.c}`,
      border: `1px solid color-mix(in srgb, ${k.c} 30%, transparent)`,
      borderLeftWidth: '2px',
      boxShadow: `inset 3px 0 12px -8px ${k.c}`,
      color: 'var(--text-primary)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      color: k.c,
      display: 'inline-flex',
      flexShrink: 0,
      marginTop: 1
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: k.icon,
    size: 18
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, title && /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--text-sm)',
      fontWeight: 'var(--weight-semibold)',
      letterSpacing: 'var(--tracking-wide)',
      textTransform: 'uppercase',
      color: k.c,
      marginBottom: children ? 2 : 0
    }
  }, title), children && /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-sm)',
      color: 'var(--text-secondary)'
    }
  }, children)), onClose && /*#__PURE__*/React.createElement("span", {
    onClick: onClose,
    style: {
      cursor: 'pointer',
      color: 'var(--text-muted)',
      display: 'inline-flex'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "x",
    size: 16
  })));
}
Object.assign(__ds_scope, { Alert });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Alert.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const TONES = {
  cyan: {
    c: 'var(--cyan-500)',
    g: 'var(--cyan-glow)'
  },
  magenta: {
    c: 'var(--magenta-500)',
    g: 'var(--magenta-glow)'
  },
  mint: {
    c: 'var(--mint-500)',
    g: 'rgba(46,255,194,.5)'
  },
  violet: {
    c: 'var(--violet-500)',
    g: 'var(--violet-glow)'
  },
  amber: {
    c: 'var(--amber-500)',
    g: 'rgba(255,176,32,.5)'
  },
  red: {
    c: 'var(--red-500)',
    g: 'rgba(255,46,91,.5)'
  },
  neutral: {
    c: 'var(--steel-400)',
    g: 'transparent'
  }
};

/**
 * NIGHTWIRE Badge — tiny status pill (NEW, HOT, BETA, counts).
 * `solid` fills with the tone; otherwise a subtle tinted outline.
 */
function Badge({
  children,
  tone = 'cyan',
  solid = false,
  glow = false,
  style = {},
  ...rest
}) {
  const t = TONES[tone] || TONES.cyan;
  const pulseable = {
    cyan: 1,
    magenta: 1,
    mint: 1,
    violet: 1
  };
  return /*#__PURE__*/React.createElement("span", _extends({
    className: glow && pulseable[tone] ? `nw-pulse-${tone}` : undefined,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: '4px',
      padding: '2px 8px',
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--text-2xs)',
      fontWeight: 'var(--weight-bold)',
      letterSpacing: 'var(--tracking-wide)',
      textTransform: 'uppercase',
      lineHeight: 1.4,
      borderRadius: 'var(--radius-pill)',
      color: solid ? 'var(--void-900)' : t.c,
      background: solid ? t.c : `color-mix(in srgb, ${t.c} 14%, transparent)`,
      border: `1px solid ${solid ? 'transparent' : `color-mix(in srgb, ${t.c} 45%, transparent)`}`,
      boxShadow: glow ? `0 0 10px ${t.g}` : 'none',
      whiteSpace: 'nowrap',
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Badge.jsx", error: String((e && e.message) || e) }); }

// components/feedback/ProgressBar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const ACCENTS = {
  cyan: 'var(--cyan-500)',
  magenta: 'var(--magenta-500)',
  mint: 'var(--mint-500)',
  violet: 'var(--violet-500)',
  gradient: 'var(--grad-primary)'
};

/**
 * NIGHTWIRE ProgressBar — neon determinate progress track.
 * Set `striped` for animated HUD hatch fill.
 */
function ProgressBar({
  value = 0,
  max = 100,
  accent = 'cyan',
  label,
  showValue = false,
  height = 8,
  style = {},
  ...rest
}) {
  const pct = Math.max(0, Math.min(100, value / max * 100));
  const fill = ACCENTS[accent] || accent;
  const glowColor = accent === 'gradient' ? 'var(--magenta-500)' : fill;
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      ...style
    }
  }, rest), (label || showValue) && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      marginBottom: 6,
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-2xs)',
      letterSpacing: 'var(--tracking-wide)',
      color: 'var(--text-secondary)'
    }
  }, /*#__PURE__*/React.createElement("span", null, label), showValue && /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-primary)'
    }
  }, Math.round(pct), "%")), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      height,
      background: 'var(--bg-inset)',
      border: '1px solid var(--border)',
      borderRadius: 'var(--radius-pill)',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: 0,
      top: 0,
      bottom: 0,
      width: `${pct}%`,
      background: fill,
      boxShadow: `0 0 10px ${glowColor}`,
      borderRadius: 'var(--radius-pill)',
      transition: 'width var(--dur-med) var(--ease-out)'
    }
  })));
}
Object.assign(__ds_scope, { ProgressBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/ProgressBar.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Tag.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const TONES = {
  cyan: 'var(--cyan-500)',
  magenta: 'var(--magenta-500)',
  mint: 'var(--mint-500)',
  violet: 'var(--violet-500)',
  amber: 'var(--amber-500)',
  red: 'var(--red-500)',
  neutral: 'var(--steel-400)'
};

/**
 * NIGHTWIRE Tag — dismissable label chip with beveled corner.
 */
function Tag({
  children,
  tone = 'neutral',
  icon = null,
  onRemove,
  style = {},
  ...rest
}) {
  const c = TONES[tone] || TONES.neutral;
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: '6px',
      padding: '3px 10px',
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-xs)',
      letterSpacing: 'var(--tracking-wide)',
      lineHeight: 1.4,
      color: c,
      background: `color-mix(in srgb, ${c} 10%, var(--bg-inset))`,
      border: `1px solid color-mix(in srgb, ${c} 40%, transparent)`,
      clipPath: 'var(--clip-bevel-sm)',
      whiteSpace: 'nowrap',
      ...style
    }
  }, rest), icon && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 13
  }), children, onRemove && /*#__PURE__*/React.createElement("span", {
    onClick: onRemove,
    style: {
      display: 'inline-flex',
      cursor: 'pointer',
      opacity: 0.7,
      marginLeft: 2
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "x",
    size: 13
  })));
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Tag.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Toast.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const KIND = {
  success: {
    c: 'var(--mint-500)',
    icon: 'check-circle'
  },
  warning: {
    c: 'var(--amber-500)',
    icon: 'alert-triangle'
  },
  danger: {
    c: 'var(--red-500)',
    icon: 'shield-alert'
  },
  info: {
    c: 'var(--cyan-500)',
    icon: 'radio'
  }
};

/**
 * NIGHTWIRE Toast — floating transient notification card.
 * Purely presentational; manage stacking/auto-dismiss in the app.
 */
function Toast({
  kind = 'info',
  title,
  children,
  onClose,
  style = {},
  ...rest
}) {
  const k = KIND[kind] || KIND.info;
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'flex',
      gap: 'var(--space-3)',
      width: 320,
      padding: 'var(--space-3) var(--space-4)',
      background: 'var(--bg-surface)',
      border: `1px solid color-mix(in srgb, ${k.c} 35%, var(--border))`,
      borderRadius: 'var(--radius-md)',
      boxShadow: `var(--shadow-3), 0 0 16px -4px ${k.c}`,
      clipPath: 'var(--clip-bevel-sm)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      color: k.c,
      display: 'inline-flex',
      flexShrink: 0,
      marginTop: 1
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: k.icon,
    size: 18
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, title && /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--text-sm)',
      fontWeight: 'var(--weight-semibold)',
      letterSpacing: 'var(--tracking-wide)',
      color: 'var(--text-primary)'
    }
  }, title), children && /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-xs)',
      color: 'var(--text-secondary)',
      marginTop: 2
    }
  }, children)), onClose && /*#__PURE__*/React.createElement("span", {
    onClick: onClose,
    style: {
      cursor: 'pointer',
      color: 'var(--text-muted)',
      display: 'inline-flex'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "x",
    size: 15
  })));
}
Object.assign(__ds_scope, { Toast });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Toast.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Tooltip.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const {
  useState
} = React;
/**
 * NIGHTWIRE Tooltip — hover popover with a neon hairline.
 */
function Tooltip({
  label,
  children,
  placement = 'top',
  style = {},
  ...rest
}) {
  const [show, setShow] = useState(false);
  const pos = {
    top: {
      bottom: '100%',
      left: '50%',
      transform: 'translateX(-50%)',
      marginBottom: 8
    },
    bottom: {
      top: '100%',
      left: '50%',
      transform: 'translateX(-50%)',
      marginTop: 8
    },
    left: {
      right: '100%',
      top: '50%',
      transform: 'translateY(-50%)',
      marginRight: 8
    },
    right: {
      left: '100%',
      top: '50%',
      transform: 'translateY(-50%)',
      marginLeft: 8
    }
  };
  return /*#__PURE__*/React.createElement("span", _extends({
    onMouseEnter: () => setShow(true),
    onMouseLeave: () => setShow(false),
    style: {
      position: 'relative',
      display: 'inline-flex',
      ...style
    }
  }, rest), children, show && /*#__PURE__*/React.createElement("span", {
    role: "tooltip",
    style: {
      position: 'absolute',
      zIndex: 'var(--z-toast)',
      ...pos[placement],
      padding: '5px 10px',
      whiteSpace: 'nowrap',
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-2xs)',
      letterSpacing: 'var(--tracking-wide)',
      color: 'var(--cyan-400)',
      background: 'var(--void-800)',
      border: '1px solid var(--cyan-600)',
      boxShadow: '0 0 12px rgba(0,240,255,.25)',
      clipPath: 'var(--clip-bevel-sm)',
      pointerEvents: 'none'
    }
  }, label));
}
Object.assign(__ds_scope, { Tooltip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Tooltip.jsx", error: String((e && e.message) || e) }); }

// components/forms/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const {
  useState
} = React;
/**
 * NIGHTWIRE Button — the primary action control.
 * Variants: primary (violet→magenta gradient), secondary (neon outline),
 * ghost (bare), danger. Optional `hud` beveled corners.
 */
function Button({
  children,
  variant = 'primary',
  size = 'md',
  hud = false,
  disabled = false,
  leftIcon = null,
  rightIcon = null,
  onClick,
  style = {},
  ...rest
}) {
  const [hover, setHover] = useState(false);
  const [press, setPress] = useState(false);
  const sizes = {
    sm: {
      h: 'var(--control-h-sm)',
      px: '14px',
      fs: 'var(--text-xs)'
    },
    md: {
      h: 'var(--control-h-md)',
      px: '20px',
      fs: 'var(--text-sm)'
    },
    lg: {
      h: 'var(--control-h-lg)',
      px: '28px',
      fs: 'var(--text-md)'
    }
  };
  const s = sizes[size] || sizes.md;
  const base = {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 'var(--space-2)',
    height: s.h,
    padding: `0 ${s.px}`,
    fontFamily: 'var(--font-display)',
    fontSize: s.fs,
    fontWeight: 'var(--weight-semibold)',
    letterSpacing: 'var(--tracking-wider)',
    textTransform: 'uppercase',
    lineHeight: 1,
    cursor: disabled ? 'not-allowed' : 'pointer',
    border: '1px solid transparent',
    borderRadius: hud ? 0 : 'var(--radius-md)',
    clipPath: hud ? 'var(--clip-bevel-sm)' : 'none',
    background: 'transparent',
    color: 'var(--text-primary)',
    transition: 'all var(--dur-fast) var(--ease-out)',
    transform: press && !disabled ? 'translateY(1px)' : 'none',
    opacity: disabled ? 0.4 : 1,
    userSelect: 'none',
    whiteSpace: 'nowrap'
  };
  const variants = {
    primary: {
      background: 'var(--grad-primary)',
      color: 'var(--frost-100)',
      boxShadow: hover && !disabled ? 'var(--glow-violet)' : '0 2px 10px rgba(168,85,247,.25)',
      backgroundSize: '140% 140%',
      backgroundPosition: hover && !disabled ? '100% 0' : '0 0'
    },
    secondary: {
      background: hover && !disabled ? 'rgba(0,240,255,.08)' : 'transparent',
      color: 'var(--cyan-500)',
      borderColor: 'var(--cyan-500)',
      boxShadow: hover && !disabled ? 'var(--glow-cyan)' : 'none'
    },
    ghost: {
      background: hover && !disabled ? 'var(--bg-hover)' : 'transparent',
      color: hover && !disabled ? 'var(--cyan-400)' : 'var(--text-secondary)'
    },
    danger: {
      background: hover && !disabled ? 'rgba(255,46,91,.10)' : 'transparent',
      color: 'var(--red-500)',
      borderColor: 'var(--red-500)',
      boxShadow: hover && !disabled ? 'var(--glow-danger)' : 'none'
    }
  };
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    className: variant === 'primary' && hover && !disabled ? 'nw-pulse-violet' : undefined,
    disabled: disabled,
    onClick: disabled ? undefined : onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => {
      setHover(false);
      setPress(false);
    },
    onMouseDown: () => setPress(true),
    onMouseUp: () => setPress(false),
    style: {
      ...base,
      ...(variants[variant] || variants.primary),
      ...style
    }
  }, rest), leftIcon, children, rightIcon);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Button.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * NIGHTWIRE Checkbox — square control with a neon check + glow when on.
 */
function Checkbox({
  checked = false,
  onChange,
  label,
  disabled = false,
  style = {},
  ...rest
}) {
  return /*#__PURE__*/React.createElement("label", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 'var(--space-2)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.45 : 1,
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-sm)',
      color: 'var(--text-secondary)',
      userSelect: 'none',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    onClick: () => !disabled && onChange && onChange(!checked),
    style: {
      width: 18,
      height: 18,
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      borderRadius: 'var(--radius-xs)',
      border: `1px solid ${checked ? 'var(--cyan-500)' : 'var(--border-strong)'}`,
      background: checked ? 'var(--cyan-500)' : 'var(--bg-inset)',
      boxShadow: checked ? 'var(--glow-cyan)' : 'none',
      color: 'var(--void-900)',
      transition: 'all var(--dur-fast) var(--ease-out)'
    }
  }, checked && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "check",
    size: 13,
    strokeWidth: 3
  })), label);
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const {
  useState
} = React;
/**
 * NIGHTWIRE IconButton — square icon-only control.
 */
function IconButton({
  name,
  variant = 'ghost',
  size = 'md',
  hud = false,
  disabled = false,
  onClick,
  title,
  style = {},
  ...rest
}) {
  const [hover, setHover] = useState(false);
  const dims = {
    sm: 30,
    md: 38,
    lg: 46
  };
  const iconSz = {
    sm: 15,
    md: 18,
    lg: 22
  };
  const d = dims[size] || dims.md;
  const variants = {
    ghost: {
      background: hover && !disabled ? 'var(--bg-hover)' : 'transparent',
      color: hover && !disabled ? 'var(--cyan-400)' : 'var(--text-secondary)',
      border: '1px solid transparent'
    },
    solid: {
      background: hover && !disabled ? 'var(--bg-surface)' : 'var(--bg-panel)',
      color: 'var(--cyan-500)',
      border: '1px solid var(--border)',
      boxShadow: hover && !disabled ? 'var(--glow-cyan)' : 'none'
    },
    outline: {
      background: hover && !disabled ? 'rgba(0,240,255,.08)' : 'transparent',
      color: 'var(--cyan-500)',
      border: '1px solid var(--cyan-500)',
      boxShadow: hover && !disabled ? 'var(--glow-cyan)' : 'none'
    }
  };
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    title: title,
    disabled: disabled,
    onClick: disabled ? undefined : onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: d,
      height: d,
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.4 : 1,
      borderRadius: hud ? 0 : 'var(--radius-md)',
      clipPath: hud ? 'var(--clip-bevel-sm)' : 'none',
      transition: 'all var(--dur-fast) var(--ease-out)',
      ...(variants[variant] || variants.ghost),
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: name,
    size: iconSz[size] || 18
  }));
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const {
  useState
} = React;
/**
 * NIGHTWIRE Input — text field with a neon focus glow.
 */
function Input({
  value,
  onChange,
  placeholder,
  type = 'text',
  size = 'md',
  icon = null,
  error = false,
  disabled = false,
  hud = false,
  style = {},
  ...rest
}) {
  const [focus, setFocus] = useState(false);
  const heights = {
    sm: 'var(--control-h-sm)',
    md: 'var(--control-h-md)',
    lg: 'var(--control-h-lg)'
  };
  const accent = error ? 'var(--red-500)' : 'var(--cyan-500)';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-2)',
      height: heights[size] || heights.md,
      padding: `0 var(--space-3)`,
      background: 'var(--bg-inset)',
      border: `1px solid ${focus ? accent : error ? 'var(--red-500)' : 'var(--border)'}`,
      borderRadius: hud ? 0 : 'var(--radius-md)',
      clipPath: hud ? 'var(--clip-bevel-sm)' : 'none',
      boxShadow: focus ? error ? 'var(--glow-danger)' : 'var(--glow-cyan)' : 'none',
      opacity: disabled ? 0.45 : 1,
      transition: 'all var(--dur-fast) var(--ease-out)',
      ...style
    }
  }, icon && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 16,
    color: focus ? accent : 'var(--text-muted)'
  }), /*#__PURE__*/React.createElement("input", _extends({
    type: type,
    value: value,
    onChange: onChange,
    placeholder: placeholder,
    disabled: disabled,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      flex: 1,
      minWidth: 0,
      background: 'transparent',
      border: 'none',
      outline: 'none',
      color: 'var(--text-primary)',
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-sm)',
      letterSpacing: 'var(--tracking-wide)'
    }
  }, rest)));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Radio.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * NIGHTWIRE Radio — round single-choice control with a neon dot.
 */
function Radio({
  checked = false,
  onChange,
  label,
  name,
  value,
  disabled = false,
  style = {},
  ...rest
}) {
  return /*#__PURE__*/React.createElement("label", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 'var(--space-2)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.45 : 1,
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-sm)',
      color: 'var(--text-secondary)',
      userSelect: 'none',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    onClick: () => !disabled && onChange && onChange(value),
    style: {
      width: 18,
      height: 18,
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      borderRadius: '999px',
      border: `1px solid ${checked ? 'var(--magenta-500)' : 'var(--border-strong)'}`,
      background: 'var(--bg-inset)',
      boxShadow: checked ? 'var(--glow-magenta)' : 'none',
      transition: 'all var(--dur-fast) var(--ease-out)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 8,
      height: 8,
      borderRadius: '999px',
      background: checked ? 'var(--magenta-500)' : 'transparent',
      transition: 'all var(--dur-fast) var(--ease-out)'
    }
  })), label);
}
Object.assign(__ds_scope, { Radio });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Radio.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const {
  useState
} = React;
/**
 * NIGHTWIRE Select — styled native select with a neon chevron.
 */
function Select({
  value,
  onChange,
  options = [],
  placeholder = 'Select…',
  size = 'md',
  disabled = false,
  hud = false,
  style = {},
  ...rest
}) {
  const [focus, setFocus] = useState(false);
  const heights = {
    sm: 'var(--control-h-sm)',
    md: 'var(--control-h-md)',
    lg: 'var(--control-h-lg)'
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      display: 'inline-flex',
      alignItems: 'center',
      height: heights[size] || heights.md,
      background: 'var(--bg-inset)',
      border: `1px solid ${focus ? 'var(--cyan-500)' : 'var(--border)'}`,
      borderRadius: hud ? 0 : 'var(--radius-md)',
      clipPath: hud ? 'var(--clip-bevel-sm)' : 'none',
      boxShadow: focus ? 'var(--glow-cyan)' : 'none',
      opacity: disabled ? 0.45 : 1,
      transition: 'all var(--dur-fast) var(--ease-out)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("select", _extends({
    value: value,
    onChange: onChange,
    disabled: disabled,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      appearance: 'none',
      WebkitAppearance: 'none',
      background: 'transparent',
      border: 'none',
      outline: 'none',
      color: value ? 'var(--text-primary)' : 'var(--text-muted)',
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-sm)',
      letterSpacing: 'var(--tracking-wide)',
      padding: '0 34px 0 var(--space-3)',
      height: '100%',
      width: '100%',
      cursor: disabled ? 'not-allowed' : 'pointer'
    }
  }, rest), placeholder && /*#__PURE__*/React.createElement("option", {
    value: "",
    disabled: true,
    hidden: true
  }, placeholder), options.map(o => {
    const opt = typeof o === 'string' ? {
      value: o,
      label: o
    } : o;
    return /*#__PURE__*/React.createElement("option", {
      key: opt.value,
      value: opt.value,
      style: {
        background: 'var(--void-600)',
        color: 'var(--text-primary)'
      }
    }, opt.label);
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      right: 'var(--space-3)',
      pointerEvents: 'none',
      color: focus ? 'var(--cyan-500)' : 'var(--text-muted)',
      display: 'inline-flex'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "chevron-down",
    size: 16
  })));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/Slider.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * NIGHTWIRE Slider — neon range control with a glowing thumb and filled track.
 */
function Slider({
  value = 50,
  min = 0,
  max = 100,
  step = 1,
  onChange,
  disabled = false,
  showValue = false,
  accent = 'var(--cyan-500)',
  style = {},
  ...rest
}) {
  const pct = (value - min) / (max - min) * 100;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-3)',
      opacity: disabled ? 0.45 : 1,
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      flex: 1,
      height: 20,
      display: 'flex',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: 0,
      right: 0,
      height: 4,
      borderRadius: 999,
      background: 'var(--bg-inset)',
      border: '1px solid var(--border)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: 0,
      width: `${pct}%`,
      height: 4,
      borderRadius: 999,
      background: accent,
      boxShadow: `0 0 8px ${accent}`
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: `calc(${pct}% - 8px)`,
      width: 16,
      height: 16,
      borderRadius: '999px',
      background: 'var(--void-900)',
      border: `2px solid ${accent}`,
      boxShadow: `0 0 10px ${accent}`
    }
  }), /*#__PURE__*/React.createElement("input", _extends({
    type: "range",
    value: value,
    min: min,
    max: max,
    step: step,
    disabled: disabled,
    onChange: e => onChange && onChange(Number(e.target.value)),
    style: {
      position: 'absolute',
      left: 0,
      right: 0,
      width: '100%',
      margin: 0,
      opacity: 0,
      height: 20,
      cursor: disabled ? 'not-allowed' : 'pointer'
    }
  }, rest))), showValue && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-xs)',
      color: 'var(--text-secondary)',
      minWidth: 34,
      textAlign: 'right'
    }
  }, Math.round(pct), "%"));
}
Object.assign(__ds_scope, { Slider });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Slider.jsx", error: String((e && e.message) || e) }); }

// components/forms/Switch.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * NIGHTWIRE Switch — pill toggle with a glowing knob.
 */
function Switch({
  checked = false,
  onChange,
  label,
  disabled = false,
  size = 'md',
  style = {},
  ...rest
}) {
  const dims = size === 'sm' ? {
    w: 38,
    h: 20,
    k: 14
  } : {
    w: 46,
    h: 24,
    k: 18
  };
  return /*#__PURE__*/React.createElement("label", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 'var(--space-3)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.45 : 1,
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-sm)',
      color: 'var(--text-secondary)',
      userSelect: 'none',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    onClick: () => !disabled && onChange && onChange(!checked),
    style: {
      position: 'relative',
      width: dims.w,
      height: dims.h,
      borderRadius: '999px',
      background: checked ? 'var(--grad-mint)' : 'var(--bg-inset)',
      border: `1px solid ${checked ? 'var(--mint-500)' : 'var(--border-strong)'}`,
      boxShadow: checked ? 'var(--glow-mint)' : 'inset 0 1px 3px rgba(0,0,0,.5)',
      transition: 'all var(--dur-med) var(--ease-out)',
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: '50%',
      left: checked ? `calc(100% - ${dims.k + 3}px)` : '3px',
      transform: 'translateY(-50%)',
      width: dims.k,
      height: dims.k,
      borderRadius: '999px',
      background: checked ? 'var(--void-900)' : 'var(--steel-400)',
      transition: 'all var(--dur-med) var(--ease-out)'
    }
  })), label);
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Switch.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Breadcrumbs.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * NIGHTWIRE Breadcrumbs — mono path trail with chevron separators.
 */
function Breadcrumbs({
  items = [],
  onNavigate,
  style = {},
  ...rest
}) {
  return /*#__PURE__*/React.createElement("nav", _extends({
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: '6px',
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-xs)',
      letterSpacing: 'var(--tracking-wide)',
      ...style
    }
  }, rest), items.map((it, i) => {
    const item = typeof it === 'string' ? {
      label: it
    } : it;
    const last = i === items.length - 1;
    return /*#__PURE__*/React.createElement(React.Fragment, {
      key: i
    }, /*#__PURE__*/React.createElement("span", {
      onClick: () => !last && onNavigate && onNavigate(item, i),
      style: {
        color: last ? 'var(--cyan-400)' : 'var(--text-muted)',
        cursor: last ? 'default' : 'pointer',
        textTransform: 'uppercase'
      }
    }, item.label), !last && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
      name: "chevron-right",
      size: 13,
      color: "var(--void-200)"
    }));
  }));
}
Object.assign(__ds_scope, { Breadcrumbs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Breadcrumbs.jsx", error: String((e && e.message) || e) }); }

// components/navigation/CommandPalette.jsx
try { (() => {
/**
 * NIGHTWIRE CommandPalette — ⌘K-style overlay launcher. Fuzzy-filters a flat
 * command list, keyboard nav (↑/↓/enter/esc), grouped sections, neon selection.
 */
function CommandPalette({
  open = false,
  onClose,
  commands = [],
  placeholder = 'Type a command or search…',
  accent = 'cyan',
  hint = 'run'
}) {
  const [q, setQ] = React.useState('');
  const [sel, setSel] = React.useState(0);
  const inputRef = React.useRef(null);
  const c = `var(--${accent}-500)`;
  const filtered = React.useMemo(() => {
    const t = q.trim().toLowerCase();
    if (!t) return commands;
    return commands.filter(cmd => {
      const hay = `${cmd.label} ${cmd.section || ''} ${(cmd.keywords || []).join(' ')}`.toLowerCase();
      let i = 0;
      for (const ch of t) {
        i = hay.indexOf(ch, i);
        if (i === -1) return false;
        i++;
      }
      return true;
    });
  }, [q, commands]);
  React.useEffect(() => {
    setSel(0);
  }, [q, open]);
  React.useEffect(() => {
    if (open && inputRef.current) inputRef.current.focus();
    if (!open) setQ('');
  }, [open]);
  const run = cmd => {
    if (!cmd) return;
    onClose && onClose();
    cmd.onRun && cmd.onRun(cmd);
  };
  const onKey = e => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setSel(s => Math.min(s + 1, filtered.length - 1));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setSel(s => Math.max(s - 1, 0));
    } else if (e.key === 'Enter') {
      e.preventDefault();
      run(filtered[sel]);
    } else if (e.key === 'Escape') {
      e.preventDefault();
      onClose && onClose();
    }
  };
  if (!open) return null;

  // group by section, preserving order of appearance
  const groups = [];
  filtered.forEach(cmd => {
    const key = cmd.section || '';
    let g = groups.find(x => x.key === key);
    if (!g) {
      g = {
        key,
        items: []
      };
      groups.push(g);
    }
    g.items.push(cmd);
  });
  let flatIndex = -1;
  return /*#__PURE__*/React.createElement("div", {
    onMouseDown: e => {
      if (e.target === e.currentTarget) onClose && onClose();
    },
    style: {
      position: 'fixed',
      inset: 0,
      zIndex: 'var(--z-modal)',
      display: 'flex',
      alignItems: 'flex-start',
      justifyContent: 'center',
      paddingTop: '12vh',
      background: 'rgba(5,6,10,.7)',
      backdropFilter: 'blur(4px)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 'min(600px,92vw)',
      background: 'var(--bg-inset)',
      border: `1px solid ${c}`,
      boxShadow: `var(--shadow-3), 0 0 40px -10px ${c}`,
      clipPath: 'var(--clip-bevel-md)',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-3)',
      padding: '14px 16px',
      borderBottom: `1px solid color-mix(in srgb, ${c} 30%, var(--border))`
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "terminal",
    size: 18,
    color: c
  }), /*#__PURE__*/React.createElement("input", {
    ref: inputRef,
    value: q,
    onChange: e => setQ(e.target.value),
    onKeyDown: onKey,
    placeholder: placeholder,
    style: {
      flex: 1,
      background: 'transparent',
      border: 'none',
      outline: 'none',
      color: 'var(--text-primary)',
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-md)',
      letterSpacing: 'var(--tracking-wide)'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-2xs)',
      color: 'var(--text-muted)',
      border: '1px solid var(--border)',
      padding: '2px 6px',
      borderRadius: 'var(--radius-xs)'
    }
  }, "ESC")), /*#__PURE__*/React.createElement("div", {
    style: {
      maxHeight: '52vh',
      overflowY: 'auto',
      padding: '6px 0'
    }
  }, groups.length === 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '28px 16px',
      textAlign: 'center',
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-sm)',
      color: 'var(--text-muted)',
      letterSpacing: 'var(--tracking-wide)'
    }
  }, "NO SIGNAL \u2014 no matching command."), groups.map(g => /*#__PURE__*/React.createElement("div", {
    key: g.key || '_'
  }, g.key && /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '8px 16px 4px',
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-2xs)',
      letterSpacing: 'var(--tracking-wider)',
      textTransform: 'uppercase',
      color: 'var(--text-muted)'
    }
  }, g.key), g.items.map(cmd => {
    flatIndex++;
    const idx = flatIndex;
    const on = idx === sel;
    return /*#__PURE__*/React.createElement("div", {
      key: cmd.id ?? cmd.label,
      onMouseEnter: () => setSel(idx),
      onMouseDown: e => {
        e.preventDefault();
        run(cmd);
      },
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 'var(--space-3)',
        margin: '0 6px',
        padding: '9px 12px',
        cursor: 'pointer',
        color: on ? c : 'var(--text-secondary)',
        background: on ? `color-mix(in srgb, ${c} 10%, transparent)` : 'transparent',
        borderLeft: on ? `2px solid ${c}` : '2px solid transparent',
        boxShadow: on ? `inset 0 0 24px -14px ${c}` : 'none'
      }
    }, cmd.icon && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
      name: cmd.icon,
      size: 16,
      color: on ? c : 'var(--text-muted)'
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        flex: 1,
        fontFamily: 'var(--font-body)',
        fontSize: 'var(--text-sm)',
        letterSpacing: 'var(--tracking-wide)',
        color: on ? 'var(--text-primary)' : 'var(--text-secondary)',
        whiteSpace: 'nowrap',
        overflow: 'hidden',
        textOverflow: 'ellipsis'
      }
    }, cmd.label), cmd.shortcut && /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--font-mono)',
        fontSize: 'var(--text-2xs)',
        color: 'var(--text-muted)',
        letterSpacing: 'var(--tracking-wide)'
      }
    }, cmd.shortcut), on && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
      name: "corner-down-left",
      size: 14,
      color: c
    }));
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-4)',
      padding: '8px 16px',
      borderTop: '1px solid var(--border)',
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-2xs)',
      color: 'var(--text-muted)',
      letterSpacing: 'var(--tracking-wide)'
    }
  }, /*#__PURE__*/React.createElement("span", null, "\u2191\u2193 navigate"), /*#__PURE__*/React.createElement("span", null, "\u23CE ", hint), /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: 'auto',
      color: c
    }
  }, "NIGHTWIRE \u2318K"))));
}
Object.assign(__ds_scope, { CommandPalette });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/CommandPalette.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Pagination.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * NIGHTWIRE Pagination — numbered page control with neon active cell.
 */
function Pagination({
  page = 1,
  pageCount = 1,
  onChange,
  style = {},
  ...rest
}) {
  const go = p => {
    if (p >= 1 && p <= pageCount && onChange) onChange(p);
  };
  const cell = (content, opts = {}) => {
    const {
      active = false,
      disabled = false,
      onClick
    } = opts;
    return /*#__PURE__*/React.createElement("button", {
      type: "button",
      disabled: disabled,
      onClick: onClick,
      style: {
        minWidth: 30,
        height: 30,
        padding: '0 6px',
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontFamily: 'var(--font-mono)',
        fontSize: 'var(--text-xs)',
        cursor: disabled ? 'not-allowed' : 'pointer',
        color: active ? 'var(--void-900)' : disabled ? 'var(--text-muted)' : 'var(--text-secondary)',
        background: active ? 'var(--cyan-500)' : 'transparent',
        border: `1px solid ${active ? 'var(--cyan-500)' : 'var(--border)'}`,
        borderRadius: 'var(--radius-sm)',
        boxShadow: active ? 'var(--glow-cyan)' : 'none',
        opacity: disabled ? 0.4 : 1
      }
    }, content);
  };
  const pages = [];
  const span = 2;
  for (let p = 1; p <= pageCount; p++) {
    if (p === 1 || p === pageCount || p >= page - span && p <= page + span) pages.push(p);else if (pages[pages.length - 1] !== '…') pages.push('…');
  }
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: '6px',
      ...style
    }
  }, rest), cell(/*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "chevron-left",
    size: 15
  }), {
    disabled: page <= 1,
    onClick: () => go(page - 1)
  }), pages.map((p, i) => p === '…' ? /*#__PURE__*/React.createElement("span", {
    key: `e${i}`,
    style: {
      color: 'var(--text-muted)',
      fontFamily: 'var(--font-mono)',
      padding: '0 2px'
    }
  }, "\u2026") : /*#__PURE__*/React.createElement(React.Fragment, {
    key: p
  }, cell(p, {
    active: p === page,
    onClick: () => go(p)
  }))), cell(/*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "chevron-right",
    size: 15
  }), {
    disabled: page >= pageCount,
    onClick: () => go(page + 1)
  }));
}
Object.assign(__ds_scope, { Pagination });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Pagination.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Tabs.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * NIGHTWIRE Tabs — underline tab bar with a neon active indicator.
 */
function Tabs({
  tabs = [],
  value,
  onChange,
  style = {},
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'flex',
      gap: 'var(--space-1)',
      borderBottom: '1px solid var(--border)',
      ...style
    }
  }, rest), tabs.map(t => {
    const tab = typeof t === 'string' ? {
      value: t,
      label: t
    } : t;
    const active = tab.value === value;
    return /*#__PURE__*/React.createElement("button", {
      key: tab.value,
      type: "button",
      onClick: () => onChange && onChange(tab.value),
      style: {
        position: 'relative',
        background: 'transparent',
        border: 'none',
        cursor: 'pointer',
        padding: '10px 16px',
        fontFamily: 'var(--font-display)',
        fontSize: 'var(--text-sm)',
        fontWeight: active ? 'var(--weight-semibold)' : 'var(--weight-medium)',
        letterSpacing: 'var(--tracking-wide)',
        textTransform: 'uppercase',
        color: active ? 'var(--cyan-400)' : 'var(--text-secondary)',
        textShadow: active ? 'var(--text-glow-cyan)' : 'none',
        transition: 'color var(--dur-fast) var(--ease-out)'
      }
    }, tab.label, active && /*#__PURE__*/React.createElement("span", {
      style: {
        position: 'absolute',
        left: 8,
        right: 8,
        bottom: -1,
        height: 2,
        background: 'var(--cyan-500)',
        boxShadow: '0 0 8px var(--cyan-500)',
        animation: 'nw-scan-drift 0s',
        animationName: 'nw-pulse-cyan',
        animationDuration: '2.4s',
        animationIterationCount: 'infinite',
        animationTimingFunction: 'var(--ease-in-out)'
      }
    }));
  }));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Tabs.jsx", error: String((e && e.message) || e) }); }

// components/surfaces/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * NIGHTWIRE Card — the base surface container.
 * Rounded by default (product style); set `hud` for beveled HUD corners.
 */
function Card({
  children,
  title,
  subtitle,
  actions,
  accent,
  hud = false,
  glow = false,
  padding = 'var(--space-5)',
  style = {},
  ...rest
}) {
  const accentColor = accent ? `var(--${accent}-500)` : null;
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      position: 'relative',
      background: 'var(--bg-panel)',
      border: `1px solid ${accentColor ? `color-mix(in srgb, ${accentColor} 35%, var(--border))` : 'var(--border)'}`,
      borderRadius: hud ? 0 : 'var(--radius-md)',
      clipPath: hud ? 'var(--clip-bevel-md)' : 'none',
      boxShadow: glow && accentColor ? `var(--shadow-2), 0 0 20px -6px ${accentColor}` : 'var(--shadow-2)',
      overflow: 'hidden',
      ...style
    }
  }, rest), accentColor && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 0,
      left: 0,
      right: 0,
      height: 2,
      background: accentColor,
      boxShadow: `0 0 10px ${accentColor}`
    }
  }), (title || actions) && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      justifyContent: 'space-between',
      gap: 'var(--space-3)',
      padding,
      paddingBottom: 'var(--space-3)'
    }
  }, /*#__PURE__*/React.createElement("div", null, title && /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--text-md)',
      fontWeight: 'var(--weight-semibold)',
      letterSpacing: 'var(--tracking-wide)',
      color: 'var(--text-primary)'
    }
  }, title), subtitle && /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-2xs)',
      letterSpacing: 'var(--tracking-wide)',
      color: 'var(--text-muted)',
      marginTop: 3,
      textTransform: 'uppercase'
    }
  }, subtitle)), actions), /*#__PURE__*/React.createElement("div", {
    style: {
      padding,
      paddingTop: title || actions ? 0 : padding
    }
  }, children));
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/surfaces/Card.jsx", error: String((e && e.message) || e) }); }

// components/surfaces/DataTable.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * NIGHTWIRE DataTable — dense mono data grid with neon header rail,
 * hover glow rows, optional per-column render + right-aligned numerics.
 */
function DataTable({
  columns = [],
  rows = [],
  accent = 'cyan',
  hud = false,
  onRowClick,
  style = {},
  ...rest
}) {
  const [hover, setHover] = React.useState(-1);
  const [sort, setSort] = React.useState({
    key: null,
    dir: 1
  });
  const c = `var(--${accent}-500)`;
  const sorted = React.useMemo(() => {
    if (!sort.key) return rows;
    const col = columns.find(x => x.key === sort.key);
    if (!col || col.sortable === false) return rows;
    return [...rows].sort((a, b) => {
      const av = a[sort.key],
        bv = b[sort.key];
      if (av == null) return 1;
      if (bv == null) return -1;
      return (av > bv ? 1 : av < bv ? -1 : 0) * sort.dir;
    });
  }, [rows, sort, columns]);
  const toggleSort = (k, sortable) => {
    if (sortable === false) return;
    setSort(s => s.key === k ? {
      key: k,
      dir: -s.dir
    } : {
      key: k,
      dir: 1
    });
  };
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      background: 'var(--bg-inset)',
      border: `1px solid var(--border)`,
      borderRadius: hud ? 0 : 'var(--radius-md)',
      clipPath: hud ? 'var(--clip-bevel-md)' : 'none',
      overflow: 'hidden',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("table", {
    style: {
      width: '100%',
      borderCollapse: 'collapse',
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-xs)'
    }
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", {
    style: {
      background: `color-mix(in srgb, ${c} 8%, transparent)`,
      borderBottom: `1px solid color-mix(in srgb, ${c} 40%, transparent)`
    }
  }, columns.map(col => {
    const active = sort.key === col.key;
    return /*#__PURE__*/React.createElement("th", {
      key: col.key,
      onClick: () => toggleSort(col.key, col.sortable),
      style: {
        textAlign: col.align || 'left',
        padding: '9px 12px',
        fontWeight: 700,
        fontSize: 'var(--text-2xs)',
        letterSpacing: 'var(--tracking-wider)',
        textTransform: 'uppercase',
        color: active ? c : 'var(--text-label)',
        cursor: col.sortable === false ? 'default' : 'pointer',
        whiteSpace: 'nowrap',
        userSelect: 'none',
        width: col.width
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        display: 'inline-flex',
        alignItems: 'center',
        gap: 5,
        flexDirection: col.align === 'right' ? 'row-reverse' : 'row'
      }
    }, col.header ?? col.key, col.sortable !== false && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
      name: active ? sort.dir === 1 ? 'chevron-up' : 'chevron-down' : 'chevrons-up-down',
      size: 12,
      color: active ? c : 'var(--text-muted)'
    })));
  }))), /*#__PURE__*/React.createElement("tbody", null, sorted.map((row, i) => {
    const on = hover === i;
    return /*#__PURE__*/React.createElement("tr", {
      key: row.id ?? i,
      onMouseEnter: () => setHover(i),
      onMouseLeave: () => setHover(-1),
      onClick: onRowClick ? () => onRowClick(row, i) : undefined,
      style: {
        borderBottom: '1px solid var(--border)',
        background: on ? `color-mix(in srgb, ${c} 7%, transparent)` : 'transparent',
        boxShadow: on ? `inset 2px 0 0 ${c}` : 'inset 2px 0 0 transparent',
        cursor: onRowClick ? 'pointer' : 'default',
        transition: 'background var(--dur-fast) var(--ease-out), box-shadow var(--dur-fast) var(--ease-out)'
      }
    }, columns.map(col => /*#__PURE__*/React.createElement("td", {
      key: col.key,
      style: {
        padding: '10px 12px',
        textAlign: col.align || 'left',
        color: col.muted ? 'var(--text-muted)' : 'var(--text-secondary)',
        whiteSpace: col.wrap ? 'normal' : 'nowrap'
      }
    }, col.render ? col.render(row[col.key], row, i) : row[col.key])));
  }), sorted.length === 0 && /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("td", {
    colSpan: columns.length,
    style: {
      padding: '26px 12px',
      textAlign: 'center',
      color: 'var(--text-muted)',
      letterSpacing: 'var(--tracking-wide)'
    }
  }, "NO SIGNAL \u2014 no records on the grid.")))));
}
Object.assign(__ds_scope, { DataTable });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/surfaces/DataTable.jsx", error: String((e && e.message) || e) }); }

// components/surfaces/HudPanel.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const TONES = {
  cyan: {
    c: 'var(--cyan-500)',
    hatch: 'var(--hatch-cyan)',
    glow: 'rgba(0,240,255,.28)',
    dim: 'rgba(0,240,255,.4)'
  },
  magenta: {
    c: 'var(--magenta-500)',
    hatch: 'var(--hatch-magenta)',
    glow: 'rgba(255,45,149,.28)',
    dim: 'rgba(255,45,149,.4)'
  },
  mint: {
    c: 'var(--mint-500)',
    hatch: 'var(--hatch-mint)',
    glow: 'rgba(46,255,194,.28)',
    dim: 'rgba(46,255,194,.4)'
  },
  violet: {
    c: 'var(--violet-500)',
    hatch: 'var(--hatch-cyan)',
    glow: 'rgba(168,85,247,.28)',
    dim: 'rgba(168,85,247,.4)'
  }
};

/**
 * NIGHTWIRE HudPanel — the signature framed container.
 * - variant="solid" (default): beveled frame, neon edge, filled title bar.
 * - variant="terminal": thin neon hairline outline with corner ticks and an
 *   inset title chip — the RETONIA/terminal-OS look (dense, wireframe-ready).
 */
function HudPanel({
  title,
  status,
  accent = 'cyan',
  variant = 'solid',
  hatch = true,
  glow = true,
  pulse = false,
  children,
  style = {},
  ...rest
}) {
  const t = TONES[accent] || TONES.cyan;
  const pulseClass = pulse && ['cyan', 'magenta', 'mint', 'violet'].includes(accent) ? `nw-pulse-${accent}` : undefined;
  if (variant === 'terminal') {
    const Tick = p => /*#__PURE__*/React.createElement("span", {
      style: {
        position: 'absolute',
        width: 9,
        height: 9,
        borderColor: t.c,
        borderStyle: 'solid',
        ...p
      }
    });
    return /*#__PURE__*/React.createElement("div", _extends({
      style: {
        position: 'relative',
        background: 'var(--bg-inset)',
        border: `1px solid ${t.dim}`,
        boxShadow: glow ? `inset 0 0 24px -14px ${t.c}, 0 0 14px -8px ${t.glow}` : 'none',
        ...style
      },
      className: pulseClass
    }, rest), /*#__PURE__*/React.createElement(Tick, {
      top: -1,
      left: -1,
      style: {
        borderWidth: '2px 0 0 2px'
      }
    }), /*#__PURE__*/React.createElement(Tick, {
      top: -1,
      right: -1,
      style: {
        borderWidth: '2px 2px 0 0'
      }
    }), /*#__PURE__*/React.createElement(Tick, {
      bottom: -1,
      left: -1,
      style: {
        borderWidth: '0 0 2px 2px'
      }
    }), /*#__PURE__*/React.createElement(Tick, {
      bottom: -1,
      right: -1,
      style: {
        borderWidth: '0 2px 2px 0'
      }
    }), (title || status) && /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        gap: 'var(--space-3)',
        padding: '7px 12px',
        borderBottom: `1px solid ${t.dim}`
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 8,
        minWidth: 0
      }
    }, hatch && /*#__PURE__*/React.createElement("span", {
      style: {
        width: 16,
        height: 8,
        background: t.hatch,
        flexShrink: 0
      }
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--font-mono)',
        fontSize: 'var(--text-2xs)',
        fontWeight: 700,
        letterSpacing: 'var(--tracking-wider)',
        textTransform: 'uppercase',
        color: t.c,
        whiteSpace: 'nowrap',
        overflow: 'hidden',
        textOverflow: 'ellipsis'
      }
    }, title)), status && /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--font-mono)',
        fontSize: 'var(--text-2xs)',
        letterSpacing: 'var(--tracking-wide)',
        color: 'var(--text-muted)',
        whiteSpace: 'nowrap'
      }
    }, status)), /*#__PURE__*/React.createElement("div", {
      style: {
        padding: 'var(--space-4)'
      }
    }, children));
  }
  return /*#__PURE__*/React.createElement("div", _extends({
    className: pulseClass,
    style: {
      clipPath: 'var(--clip-bevel-md)',
      background: t.c,
      padding: 1,
      boxShadow: glow ? `0 0 22px -4px ${t.glow}` : 'none',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      clipPath: 'var(--clip-bevel-md)',
      background: 'var(--bg-panel)',
      minHeight: 40
    }
  }, (title || status) && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: 'var(--space-3)',
      padding: '8px 14px',
      borderBottom: `1px solid color-mix(in srgb, ${t.c} 30%, transparent)`,
      background: `color-mix(in srgb, ${t.c} 7%, transparent)`
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-2)',
      minWidth: 0
    }
  }, hatch && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 22,
      height: 10,
      background: t.hatch,
      flexShrink: 0
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--text-xs)',
      fontWeight: 'var(--weight-bold)',
      letterSpacing: 'var(--tracking-widest)',
      textTransform: 'uppercase',
      color: t.c,
      textShadow: `0 0 8px ${t.glow}`,
      whiteSpace: 'nowrap',
      overflow: 'hidden',
      textOverflow: 'ellipsis'
    }
  }, title)), status && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-2xs)',
      letterSpacing: 'var(--tracking-wide)',
      color: 'var(--text-muted)',
      whiteSpace: 'nowrap'
    }
  }, status)), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 'var(--space-4)'
    }
  }, children)));
}
Object.assign(__ds_scope, { HudPanel });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/surfaces/HudPanel.jsx", error: String((e && e.message) || e) }); }

// components/surfaces/StatCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const TONES = {
  cyan: 'var(--cyan-500)',
  magenta: 'var(--magenta-500)',
  mint: 'var(--mint-500)',
  violet: 'var(--violet-500)',
  amber: 'var(--amber-500)',
  red: 'var(--red-500)'
};

/**
 * NIGHTWIRE StatCard — KPI tile with label, big value, delta and icon.
 */
function StatCard({
  label,
  value,
  delta,
  trend = 'up',
  icon,
  accent = 'cyan',
  style = {},
  ...rest
}) {
  const c = TONES[accent] || TONES.cyan;
  const deltaColor = trend === 'down' ? 'var(--red-500)' : 'var(--mint-500)';
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      position: 'relative',
      background: 'var(--bg-panel)',
      border: '1px solid var(--border)',
      borderRadius: 'var(--radius-md)',
      padding: 'var(--space-4)',
      overflow: 'hidden',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      background: `radial-gradient(120px 80px at 100% 0, color-mix(in srgb, ${c} 16%, transparent), transparent 70%)`,
      pointerEvents: 'none'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      marginBottom: 'var(--space-3)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-2xs)',
      letterSpacing: 'var(--tracking-wider)',
      textTransform: 'uppercase',
      color: 'var(--text-muted)'
    }
  }, label), icon && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      width: 30,
      height: 30,
      alignItems: 'center',
      justifyContent: 'center',
      color: c,
      background: `color-mix(in srgb, ${c} 12%, transparent)`,
      border: `1px solid color-mix(in srgb, ${c} 35%, transparent)`,
      borderRadius: 'var(--radius-sm)'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 16
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--text-2xl)',
      fontWeight: 'var(--weight-bold)',
      letterSpacing: 'var(--tracking-tight)',
      color: 'var(--text-primary)',
      lineHeight: 1
    }
  }, value), delta && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      display: 'inline-flex',
      alignItems: 'center',
      gap: 4,
      marginTop: 'var(--space-2)',
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-xs)',
      color: deltaColor
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: trend === 'down' ? 'trending-down' : 'trending-up',
    size: 14
  }), delta));
}
Object.assign(__ds_scope, { StatCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/surfaces/StatCard.jsx", error: String((e && e.message) || e) }); }

// ui_kits/marketing/landing.jsx
try { (() => {
// NIGHTWIRE marketing — landing page (V3: full terminal + CRT + glitch). Exports LandingPage.
const {
  Button,
  IconButton,
  Badge,
  Tag,
  Card,
  HudPanel,
  StatCard,
  ProgressBar,
  Input,
  Icon
} = window.NightwireDesignSystem_f7f010;
function Nav() {
  const links = ['Product', 'Modules', 'Grid', 'Pricing', 'Docs'];
  return /*#__PURE__*/React.createElement("nav", {
    style: {
      position: 'sticky',
      top: 0,
      zIndex: 100,
      display: 'flex',
      alignItems: 'center',
      gap: 26,
      padding: '14px 40px',
      background: 'rgba(8,11,18,.82)',
      backdropFilter: 'blur(12px)',
      borderBottom: '1px solid rgba(255,45,149,.28)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 28,
      height: 28,
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'var(--grad-primary)',
      clipPath: 'var(--clip-bevel-sm)',
      color: '#fff'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "hexagon",
    size: 17
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 700,
      fontSize: 19,
      letterSpacing: '.04em',
      color: 'var(--frost-100)',
      textShadow: '1.5px 0 rgba(255,45,149,.6),-1.5px 0 rgba(0,240,255,.6)'
    }
  }, "NIGHTWIRE")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 22,
      marginLeft: 18
    }
  }, links.map(l => /*#__PURE__*/React.createElement("a", {
    key: l,
    href: "#",
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 12,
      letterSpacing: '.1em',
      textTransform: 'uppercase',
      color: 'var(--text-secondary)',
      textDecoration: 'none'
    }
  }, l))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginLeft: 'auto',
      display: 'flex',
      alignItems: 'center',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 12,
      letterSpacing: '.1em',
      textTransform: 'uppercase',
      color: 'var(--text-secondary)'
    }
  }, "Sign in"), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "sm"
  }, "Jack in")));
}
function Hero() {
  return /*#__PURE__*/React.createElement("section", {
    className: "nw-grid-bg nw-crt",
    style: {
      position: 'relative',
      padding: '90px 40px 70px',
      textAlign: 'center',
      background: 'radial-gradient(120% 80% at 50% -10%,rgba(255,45,149,.16),transparent 55%),radial-gradient(90% 60% at 50% 120%,rgba(0,240,255,.12),transparent 60%)',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'inline-flex',
      marginBottom: 22
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: "mint",
    glow: true
  }, "\u25CF SYSTEM ONLINE \xB7 v3.0")), /*#__PURE__*/React.createElement("h1", {
    className: "nw-glitch",
    style: {
      fontSize: 76,
      lineHeight: 1.02,
      letterSpacing: '.01em',
      maxWidth: 900,
      margin: '0 auto',
      fontWeight: 700
    }
  }, "BUILD FOR THE FUTURE"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 19,
      color: 'var(--text-secondary)',
      maxWidth: 560,
      margin: '20px auto 0',
      lineHeight: 1.5
    }
  }, "The neon-on-void interface system for netrunners. Ship dashboards, consoles and HUDs that look like they were pulled straight off the grid."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 14,
      justifyContent: 'center',
      marginTop: 30
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    rightIcon: /*#__PURE__*/React.createElement(Icon, {
      name: "arrow-right",
      size: 18
    })
  }, "Deploy now"), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "lg",
    hud: true,
    leftIcon: /*#__PURE__*/React.createElement(Icon, {
      name: "play",
      size: 16
    })
  }, "Watch demo")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 32,
      justifyContent: 'center',
      marginTop: 44,
      fontFamily: 'var(--font-mono)',
      fontSize: 12,
      color: 'var(--text-muted)',
      letterSpacing: '.06em'
    }
  }, ['NCPD', 'ARASAKA', 'MILITECH', 'KANG TAO', 'ZETATECH'].map(c => /*#__PURE__*/React.createElement("span", {
    key: c
  }, c))));
}
const FEATURES = [{
  icon: 'layout-dashboard',
  title: 'HUD Panels',
  accent: 'cyan',
  body: 'Beveled frames with glowing neon edges, hatch stripes and mono status readouts — the signature look, out of the box.'
}, {
  icon: 'zap',
  title: 'Instant Motion',
  accent: 'magenta',
  body: 'Snappy, mechanical transitions with pulsing glow on every active element. No bounce, no lag.'
}, {
  icon: 'shield',
  title: 'ICE-Grade Tokens',
  accent: 'mint',
  body: 'A full token system: neon palette, gradients, glows, CRT textures and type — themed and consistent across every surface.'
}];
function Features() {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      padding: '70px 40px',
      maxWidth: 1120,
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      marginBottom: 40
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 12,
      letterSpacing: '.3em',
      color: 'var(--cyan-500)',
      textTransform: 'uppercase'
    }
  }, "// Modules"), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontSize: 38,
      color: 'var(--frost-100)',
      marginTop: 8
    }
  }, "Everything on the grid")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3,1fr)',
      gap: 18
    }
  }, FEATURES.map(f => /*#__PURE__*/React.createElement(HudPanel, {
    key: f.title,
    variant: "terminal",
    title: f.title,
    status: "+++",
    accent: f.accent
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      width: 44,
      height: 44,
      alignItems: 'center',
      justifyContent: 'center',
      color: `var(--${f.accent}-500)`,
      background: `color-mix(in srgb, var(--${f.accent}-500) 12%, transparent)`,
      border: `1px solid color-mix(in srgb, var(--${f.accent}-500) 35%, transparent)`,
      marginBottom: 14,
      clipPath: 'var(--clip-bevel-sm)',
      boxShadow: `0 0 14px -4px var(--${f.accent}-500)`
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: f.icon,
    size: 22
  })), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 15,
      color: 'var(--text-secondary)',
      lineHeight: 1.5,
      margin: 0
    }
  }, f.body)))));
}
function StatBand() {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      padding: '10px 40px 60px',
      maxWidth: 1120,
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4,1fr)',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement(StatCard, {
    label: "Runners",
    value: "128K",
    delta: "+18%",
    icon: "users",
    accent: "cyan"
  }), /*#__PURE__*/React.createElement(StatCard, {
    label: "Uptime",
    value: "99.99%",
    delta: "+0.1%",
    icon: "activity",
    accent: "mint"
  }), /*#__PURE__*/React.createElement(StatCard, {
    label: "Modules",
    value: "21",
    delta: "+3",
    icon: "boxes",
    accent: "magenta"
  }), /*#__PURE__*/React.createElement(StatCard, {
    label: "Nodes",
    value: "2,048",
    delta: "+96",
    icon: "server",
    accent: "violet"
  })));
}
function Showcase() {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      padding: '30px 40px 70px',
      maxWidth: 1120,
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement(HudPanel, {
    variant: "terminal",
    title: "Live Console",
    status: "24.06.99 \xB7 SECURE",
    accent: "cyan",
    pulse: true
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1.6fr 1fr',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      color: 'var(--text-muted)',
      letterSpacing: '.1em',
      marginBottom: 10
    }
  }, "> THROUGHPUT \xB7 REQ/S"), /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 480 140",
    width: "100%",
    preserveAspectRatio: "none"
  }, /*#__PURE__*/React.createElement("defs", null, /*#__PURE__*/React.createElement("linearGradient", {
    id: "mg",
    x1: "0",
    y1: "0",
    x2: "0",
    y2: "1"
  }, /*#__PURE__*/React.createElement("stop", {
    offset: "0%",
    stopColor: "var(--cyan-500)",
    stopOpacity: ".35"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: "100%",
    stopColor: "var(--cyan-500)",
    stopOpacity: "0"
  }))), /*#__PURE__*/React.createElement("polygon", {
    points: "0,110 48,90 96,98 144,64 192,74 240,44 288,52 336,28 384,36 432,16 480,22 480,140 0,140",
    fill: "url(#mg)"
  }), /*#__PURE__*/React.createElement("polyline", {
    points: "0,110 48,90 96,98 144,64 192,74 240,44 288,52 336,28 384,36 432,16 480,22",
    fill: "none",
    stroke: "var(--cyan-500)",
    strokeWidth: "2.5",
    style: {
      filter: 'drop-shadow(0 0 6px rgba(0,240,255,.6))'
    }
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 14,
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement(ProgressBar, {
    value: 72,
    label: "CPU LOAD",
    showValue: true,
    accent: "magenta"
  }), /*#__PURE__*/React.createElement(ProgressBar, {
    value: 54,
    label: "ICE INTEGRITY",
    showValue: true,
    accent: "mint"
  }), /*#__PURE__*/React.createElement(ProgressBar, {
    value: 88,
    label: "BANDWIDTH",
    showValue: true,
    accent: "cyan"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Tag, {
    tone: "cyan",
    icon: "cpu"
  }, "netrunner"), /*#__PURE__*/React.createElement(Tag, {
    tone: "magenta"
  }, "#eddies"), /*#__PURE__*/React.createElement(Tag, {
    tone: "mint"
  }, "encrypted"))))));
}
const PLANS = [{
  name: 'Street',
  price: '$0',
  tag: null,
  accent: 'cyan',
  feats: ['1 operator', 'Core components', 'Community grid', 'Lucide icons'],
  cta: 'Start free',
  variant: 'secondary'
}, {
  name: 'Runner',
  price: '$49',
  tag: 'POPULAR',
  accent: 'magenta',
  feats: ['Unlimited operators', 'All modules + HUD kit', 'Priority sync', 'Custom tokens', 'ICE support'],
  cta: 'Jack in',
  variant: 'primary'
}, {
  name: 'Corpo',
  price: 'Custom',
  tag: null,
  accent: 'violet',
  feats: ['SSO + audit log', 'On-prem grid', 'Dedicated node', 'SLA 99.99%'],
  cta: 'Contact',
  variant: 'secondary'
}];
function Pricing() {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      padding: '60px 40px',
      maxWidth: 1120,
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      marginBottom: 40
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 12,
      letterSpacing: '.3em',
      color: 'var(--magenta-500)',
      textTransform: 'uppercase'
    }
  }, "// Access tiers"), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontSize: 38,
      color: 'var(--frost-100)',
      marginTop: 8
    }
  }, "Pick your rig")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3,1fr)',
      gap: 18,
      alignItems: 'start'
    }
  }, PLANS.map(p => {
    const popular = p.name === 'Runner';
    return /*#__PURE__*/React.createElement(HudPanel, {
      key: p.name,
      variant: "terminal",
      title: p.name,
      status: popular ? 'POPULAR' : '///',
      accent: p.accent,
      pulse: popular,
      style: popular ? {
        transform: 'scale(1.03)'
      } : {}
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'baseline',
        gap: 6,
        margin: '4px 0 18px'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--font-display)',
        fontWeight: 700,
        fontSize: 44,
        color: 'var(--frost-100)'
      }
    }, p.price), p.price !== 'Custom' && /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--font-mono)',
        fontSize: 12,
        color: 'var(--text-muted)'
      }
    }, "/mo")), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        flexDirection: 'column',
        gap: 10,
        marginBottom: 20
      }
    }, p.feats.map(f => /*#__PURE__*/React.createElement("div", {
      key: f,
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 9,
        fontFamily: 'var(--font-body)',
        fontSize: 14,
        color: 'var(--text-secondary)'
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "check",
      size: 15,
      color: `var(--${p.accent}-500)`
    }), f))), /*#__PURE__*/React.createElement(Button, {
      variant: p.variant,
      style: {
        width: '100%'
      }
    }, p.cta));
  })));
}
function CTA() {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      padding: '30px 40px 80px',
      maxWidth: 1120,
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "nw-crt",
    style: {
      position: 'relative',
      textAlign: 'center',
      padding: '56px 30px',
      background: 'var(--grad-surface)',
      border: '1px solid rgba(255,45,149,.4)',
      clipPath: 'var(--clip-bevel-md)',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "nw-grid-bg",
    style: {
      position: 'absolute',
      inset: 0,
      opacity: .5
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("h2", {
    className: "nw-glitch",
    style: {
      fontSize: 44,
      fontWeight: 700
    }
  }, "READY TO BREACH?"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 17,
      color: 'var(--text-secondary)',
      maxWidth: 460,
      margin: '14px auto 26px'
    }
  }, "Jack into NIGHTWIRE and ship your first console tonight."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12,
      justifyContent: 'center',
      maxWidth: 420,
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement(Input, {
    placeholder: "operator@grid.net",
    icon: "mail",
    style: {
      flex: 1
    }
  }), /*#__PURE__*/React.createElement(Button, {
    variant: "primary"
  }, "Deploy")))));
}
function Footer() {
  const cols = {
    Product: ['Components', 'HUD kit', 'Tokens', 'Changelog'],
    Grid: ['Status', 'Nodes', 'Security', 'API'],
    Company: ['About', 'Careers', 'Contact']
  };
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      borderTop: '1px solid rgba(255,45,149,.22)',
      padding: '40px 40px 30px',
      background: 'var(--void-800)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1120,
      margin: '0 auto',
      display: 'grid',
      gridTemplateColumns: '1.5fr 1fr 1fr 1fr',
      gap: 30
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 700,
      fontSize: 18,
      letterSpacing: '.04em',
      color: 'var(--frost-100)',
      textShadow: '1.5px 0 rgba(255,45,149,.6),-1.5px 0 rgba(0,240,255,.6)'
    }
  }, "NIGHTWIRE"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      color: 'var(--text-muted)',
      marginTop: 10,
      letterSpacing: '.06em',
      maxWidth: 220
    }
  }, "Neon-on-void interface system. Built for the future \xB7 NCPD/0023"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      marginTop: 14
    }
  }, /*#__PURE__*/React.createElement(IconButton, {
    name: "github",
    variant: "ghost",
    size: "sm"
  }), /*#__PURE__*/React.createElement(IconButton, {
    name: "twitter",
    variant: "ghost",
    size: "sm"
  }), /*#__PURE__*/React.createElement(IconButton, {
    name: "rss",
    variant: "ghost",
    size: "sm"
  }))), Object.entries(cols).map(([h, items]) => /*#__PURE__*/React.createElement("div", {
    key: h
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      letterSpacing: '.16em',
      textTransform: 'uppercase',
      color: 'var(--cyan-500)',
      marginBottom: 12
    }
  }, "// ", h), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 9
    }
  }, items.map(i => /*#__PURE__*/React.createElement("a", {
    key: i,
    href: "#",
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 14,
      color: 'var(--text-secondary)',
      textDecoration: 'none'
    }
  }, i)))))), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1120,
      margin: '26px auto 0',
      paddingTop: 16,
      borderTop: '1px solid var(--border)',
      display: 'flex',
      justifyContent: 'space-between',
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      color: 'var(--text-muted)',
      letterSpacing: '.06em'
    }
  }, /*#__PURE__*/React.createElement("span", null, "\xA9 2077 NIGHTWIRE SYSTEMS"), /*#__PURE__*/React.createElement("span", null, "NO LIMITS / NO RULES")));
}
function LandingPage() {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--bg-app)',
      minHeight: '100%'
    }
  }, /*#__PURE__*/React.createElement(Nav, null), /*#__PURE__*/React.createElement(Hero, null), /*#__PURE__*/React.createElement(Features, null), /*#__PURE__*/React.createElement(StatBand, null), /*#__PURE__*/React.createElement(Showcase, null), /*#__PURE__*/React.createElement(Pricing, null), /*#__PURE__*/React.createElement(CTA, null), /*#__PURE__*/React.createElement(Footer, null));
}
window.LandingPage = LandingPage;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/marketing/landing.jsx", error: String((e && e.message) || e) }); }

// ui_kits/netrunner-console/app.jsx
try { (() => {
// NIGHTWIRE netrunner-console — app shell + screens (terminal/HUD lean).
const {
  Button,
  IconButton,
  Input,
  Select,
  Card,
  StatCard,
  HudPanel,
  Badge,
  Tag,
  Tabs,
  ProgressBar,
  Switch,
  Icon
} = window.NightwireDesignSystem_f7f010;
const {
  NeonAreaChart,
  NeonBars,
  NeonDonut,
  Sparkline,
  Wireframe
} = window;
const {
  useState
} = React;
const NAV = [{
  id: 'overview',
  label: 'Overview',
  icon: 'layout-dashboard'
}, {
  id: 'analytics',
  label: 'Analytics',
  icon: 'activity'
}, {
  id: 'datastream',
  label: 'Datastream',
  icon: 'git-branch'
}, {
  id: 'ice',
  label: 'ICE',
  icon: 'shield'
}, {
  id: 'messages',
  label: 'Comms',
  icon: 'message-square'
}, {
  id: 'settings',
  label: 'Settings',
  icon: 'settings'
}];

// Thin circuit-trace frame around the whole console (ref #4).
function CircuitFrame({
  children
}) {
  const node = p => /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      width: 6,
      height: 6,
      background: 'var(--magenta-500)',
      boxShadow: '0 0 6px var(--magenta-500)',
      ...p
    }
  });
  const tick = p => /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      background: 'rgba(255,45,149,.5)',
      ...p
    }
  });
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      flex: 1,
      minWidth: 0,
      margin: 8,
      border: '1px solid rgba(255,45,149,.35)',
      display: 'flex',
      flexDirection: 'column',
      overflow: 'hidden'
    }
  }, node({
    top: -3,
    left: -3
  }), node({
    top: -3,
    right: -3
  }), node({
    bottom: -3,
    left: -3
  }), node({
    bottom: -3,
    right: -3
  }), tick({
    top: -1,
    left: '18%',
    width: 40,
    height: 2
  }), tick({
    bottom: -1,
    right: '22%',
    width: 40,
    height: 2
  }), tick({
    top: '30%',
    left: -1,
    width: 2,
    height: 30
  }), tick({
    top: '55%',
    right: -1,
    width: 2,
    height: 30
  }), children);
}
function Wordmark({
  small
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 700,
      fontSize: small ? 18 : 22,
      letterSpacing: '.04em',
      color: 'var(--frost-100)',
      textShadow: '2px 0 rgba(255,45,149,.7),-2px 0 rgba(0,240,255,.7)',
      lineHeight: 1
    }
  }, "NIGHTWIRE");
}
function Sidebar({
  active,
  onNav
}) {
  return /*#__PURE__*/React.createElement("aside", {
    style: {
      width: 214,
      flexShrink: 0,
      background: 'var(--void-800)',
      borderRight: '1px solid rgba(255,45,149,.28)',
      display: 'flex',
      flexDirection: 'column',
      padding: '18px 12px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 6px 8px',
      display: 'flex',
      alignItems: 'center',
      gap: 9
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 28,
      height: 28,
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'var(--grad-primary)',
      color: '#fff',
      clipPath: 'var(--clip-bevel-sm)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "hexagon",
    size: 17
  })), /*#__PURE__*/React.createElement(Wordmark, {
    small: true
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 9,
      letterSpacing: '.28em',
      color: 'var(--text-muted)',
      padding: '0 6px 14px',
      borderBottom: '1px solid var(--border)',
      marginBottom: 12
    }
  }, "// NCPD/0023 \xB7 NODE 0x4F"), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 2
    }
  }, NAV.map(n => {
    const on = n.id === active;
    return /*#__PURE__*/React.createElement("button", {
      key: n.id,
      onClick: () => onNav(n.id),
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 10,
        padding: '9px 11px',
        cursor: 'pointer',
        textAlign: 'left',
        fontFamily: 'var(--font-mono)',
        fontSize: 12,
        letterSpacing: '.08em',
        textTransform: 'uppercase',
        color: on ? 'var(--magenta-400)' : 'var(--text-secondary)',
        background: on ? 'rgba(255,45,149,.10)' : 'transparent',
        borderLeft: on ? '2px solid var(--magenta-500)' : '2px solid transparent',
        boxShadow: on ? 'inset 0 0 20px -12px var(--magenta-500)' : 'none',
        position: 'relative'
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: n.icon,
      size: 16
    }), n.label, on && /*#__PURE__*/React.createElement("span", {
      style: {
        marginLeft: 'auto',
        color: 'var(--magenta-500)',
        fontSize: 10
      }
    }, "\u25C4"));
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'auto'
    }
  }, /*#__PURE__*/React.createElement(HudPanel, {
    variant: "terminal",
    title: "Deck",
    status: "v3.0",
    accent: "mint"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      color: 'var(--text-secondary)',
      marginBottom: 7,
      letterSpacing: '.08em'
    }
  }, "CHARGE \xB7 78%"), /*#__PURE__*/React.createElement(ProgressBar, {
    value: 78,
    accent: "mint",
    height: 5
  }))));
}
function TopBar({
  onLogout
}) {
  return /*#__PURE__*/React.createElement("header", {
    style: {
      height: 54,
      flexShrink: 0,
      borderBottom: '1px solid rgba(255,45,149,.22)',
      background: 'var(--void-800)',
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      padding: '0 16px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      color: 'var(--mint-500)',
      letterSpacing: '.12em'
    }
  }, "\u25CF LINK STABLE"), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      maxWidth: 380,
      marginLeft: 8
    }
  }, /*#__PURE__*/React.createElement(Input, {
    placeholder: "query the grid\u2026",
    icon: "terminal"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      marginLeft: 'auto',
      display: 'flex',
      alignItems: 'center',
      gap: 9
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      color: 'var(--text-muted)'
    }
  }, "24.06.99"), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement(IconButton, {
    name: "bell",
    variant: "ghost"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: 4,
      right: 4,
      width: 7,
      height: 7,
      borderRadius: 999,
      background: 'var(--magenta-500)',
      boxShadow: '0 0 6px var(--magenta-500)'
    }
  })), /*#__PURE__*/React.createElement(IconButton, {
    name: "log-out",
    variant: "ghost",
    title: "Jack out",
    onClick: onLogout
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 32,
      height: 32,
      background: 'var(--grad-cyber)',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: '#fff',
      fontFamily: 'var(--font-display)',
      fontWeight: 700,
      fontSize: 13,
      clipPath: 'var(--clip-bevel-sm)'
    }
  }, "V")));
}
function LoginScreen({
  onLogin
}) {
  const [code, setCode] = useState('');
  return /*#__PURE__*/React.createElement("div", {
    className: "nw-grid-bg nw-crt",
    style: {
      height: '100%',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'radial-gradient(120% 90% at 50% 0,rgba(255,45,149,.12),#05060a 65%)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 380
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      marginBottom: 20
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "nw-glitch",
    style: {
      fontWeight: 700,
      fontSize: 40,
      letterSpacing: '.04em'
    }
  }, "NIGHTWIRE"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      letterSpacing: '.3em',
      color: 'var(--magenta-500)',
      textTransform: 'uppercase',
      marginTop: 6
    }
  }, "Netrunner Console")), /*#__PURE__*/React.createElement(HudPanel, {
    variant: "terminal",
    title: "Jack In",
    status: "SECURE \u2588\u2588",
    accent: "magenta",
    pulse: true
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      color: 'var(--text-muted)',
      marginBottom: 6,
      letterSpacing: '.1em'
    }
  }, "> OPERATOR"), /*#__PURE__*/React.createElement(Input, {
    placeholder: "V",
    icon: "user",
    style: {
      marginBottom: 12
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      color: 'var(--text-muted)',
      marginBottom: 6,
      letterSpacing: '.1em'
    }
  }, "> ACCESS CODE"), /*#__PURE__*/React.createElement(Input, {
    type: "password",
    placeholder: "\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022",
    icon: "key",
    value: code,
    onChange: e => setCode(e.target.value),
    style: {
      marginBottom: 18
    }
  }), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    onClick: onLogin,
    style: {
      width: '100%'
    },
    rightIcon: /*#__PURE__*/React.createElement(Icon, {
      name: "arrow-right",
      size: 16
    })
  }, "Deploy")), /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      marginTop: 14,
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      color: 'var(--text-muted)',
      letterSpacing: '.1em'
    }
  }, "NIGHT CITY GRID \xB7 24.06.99 \xB7 NO LIMITS / NO RULES")));
}
const ORDERS = [{
  id: '#VX2891',
  item: 'Sandevistan MK.4',
  px: '$12,900',
  st: 'shipped',
  tone: 'mint'
}, {
  id: '#VX2884',
  item: 'Kiroshi Optics',
  px: '$3,400',
  st: 'pending',
  tone: 'amber'
}, {
  id: '#VX2877',
  item: 'Gorilla Arms',
  px: '$8,750',
  st: 'shipped',
  tone: 'mint'
}, {
  id: '#VX2871',
  item: 'Cyberdeck X-01',
  px: '$21,000',
  st: 'flagged',
  tone: 'red'
}, {
  id: '#VX2863',
  item: 'Berserk Mod',
  px: '$5,120',
  st: 'shipped',
  tone: 'mint'
}];
function DashboardScreen() {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 18,
      display: 'flex',
      flexDirection: 'column',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontSize: 22,
      letterSpacing: '.02em',
      color: 'var(--frost-100)'
    }
  }, "Overview"), /*#__PURE__*/React.createElement(Badge, {
    tone: "magenta",
    glow: true
  }, "LIVE"), /*#__PURE__*/React.createElement("div", {
    style: {
      marginLeft: 'auto',
      display: 'flex',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "sm",
    leftIcon: /*#__PURE__*/React.createElement(Icon, {
      name: "calendar",
      size: 14
    })
  }, "24h"), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "sm",
    hud: true,
    leftIcon: /*#__PURE__*/React.createElement(Icon, {
      name: "download",
      size: 14
    })
  }, "Export"))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4,1fr)',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(StatCard, {
    label: "Total revenue",
    value: "$8.75M",
    delta: "+12.5%",
    trend: "up",
    icon: "dollar-sign",
    accent: "cyan"
  }), /*#__PURE__*/React.createElement(StatCard, {
    label: "Active runners",
    value: "24,512",
    delta: "+4.2%",
    trend: "up",
    icon: "users",
    accent: "magenta"
  }), /*#__PURE__*/React.createElement(StatCard, {
    label: "New contracts",
    value: "9,821",
    delta: "+9.1%",
    trend: "up",
    icon: "file-text",
    accent: "mint"
  }), /*#__PURE__*/React.createElement(StatCard, {
    label: "Threat level",
    value: "LOW",
    delta: "-8.1%",
    trend: "down",
    icon: "shield",
    accent: "violet"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1.9fr 1fr',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(HudPanel, {
    variant: "terminal",
    title: "Traffic Overview",
    status: "req \xB7 24h",
    accent: "cyan"
  }, /*#__PURE__*/React.createElement(NeonAreaChart, {
    id: "tr",
    data: [22, 30, 26, 40, 36, 52, 48, 60, 55, 72, 66, 84]
  })), /*#__PURE__*/React.createElement(HudPanel, {
    variant: "terminal",
    title: "Traffic Source",
    status: "by channel",
    accent: "magenta"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement(NeonDonut, {
    segments: [{
      value: 44,
      color: 'var(--cyan-500)'
    }, {
      value: 30,
      color: 'var(--magenta-500)'
    }, {
      value: 16,
      color: 'var(--mint-500)'
    }, {
      value: 10,
      color: 'var(--violet-500)'
    }],
    size: 132
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 700,
      fontSize: 20,
      color: 'var(--frost-100)'
    }
  }, "12.5K"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 9,
      color: 'var(--text-muted)',
      letterSpacing: '.1em'
    }
  }, "TOTAL"))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 7,
      fontFamily: 'var(--font-mono)',
      fontSize: 11
    }
  }, [['Direct', '44%', 'var(--cyan-500)'], ['Grid', '30%', 'var(--magenta-500)'], ['Organic', '16%', 'var(--mint-500)'], ['Referral', '10%', 'var(--violet-500)']].map(r => /*#__PURE__*/React.createElement("div", {
    key: r[0],
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      color: 'var(--text-secondary)',
      minWidth: 130
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 8,
      height: 8,
      background: r[2]
    }
  }), r[0], /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: 'auto',
      color: 'var(--text-primary)'
    }
  }, r[1]))))))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1.9fr 1fr',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(HudPanel, {
    variant: "terminal",
    title: "Recent Orders",
    status: "cyberware mkt",
    accent: "cyan"
  }, /*#__PURE__*/React.createElement("table", {
    style: {
      width: '100%',
      borderCollapse: 'collapse',
      fontFamily: 'var(--font-mono)',
      fontSize: 12
    }
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", {
    style: {
      textAlign: 'left',
      color: 'var(--text-muted)',
      textTransform: 'uppercase',
      fontSize: 10,
      letterSpacing: '.1em'
    }
  }, /*#__PURE__*/React.createElement("th", {
    style: {
      padding: '6px 8px',
      fontWeight: 400
    }
  }, "ID"), /*#__PURE__*/React.createElement("th", {
    style: {
      padding: '6px 8px',
      fontWeight: 400
    }
  }, "Item"), /*#__PURE__*/React.createElement("th", {
    style: {
      padding: '6px 8px',
      fontWeight: 400
    }
  }, "Price"), /*#__PURE__*/React.createElement("th", {
    style: {
      padding: '6px 8px',
      fontWeight: 400
    }
  }, "Status"))), /*#__PURE__*/React.createElement("tbody", null, ORDERS.map(o => /*#__PURE__*/React.createElement("tr", {
    key: o.id,
    style: {
      borderTop: '1px solid var(--border)',
      color: 'var(--text-secondary)'
    }
  }, /*#__PURE__*/React.createElement("td", {
    style: {
      padding: '9px 8px',
      color: 'var(--cyan-400)'
    }
  }, o.id), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: '9px 8px',
      color: 'var(--text-primary)'
    }
  }, o.item), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: '9px 8px'
    }
  }, o.px), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: '9px 8px'
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: o.tone
  }, o.st))))))), /*#__PURE__*/React.createElement(HudPanel, {
    variant: "terminal",
    title: "System Status",
    status: "realtime",
    accent: "mint"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(ProgressBar, {
    value: 38,
    label: "SERVER LOAD",
    showValue: true,
    accent: "cyan"
  }), /*#__PURE__*/React.createElement(ProgressBar, {
    value: 64,
    label: "ICE INTEGRITY",
    showValue: true,
    accent: "mint"
  }), /*#__PURE__*/React.createElement(ProgressBar, {
    value: 82,
    label: "MEMORY",
    showValue: true,
    accent: "magenta"
  }), /*#__PURE__*/React.createElement(ProgressBar, {
    value: 21,
    label: "BANDWIDTH",
    showValue: true,
    accent: "violet"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      paddingTop: 6,
      borderTop: '1px solid var(--border)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      color: 'var(--text-secondary)',
      letterSpacing: '.06em'
    }
  }, "AUTO-DEFEND"), /*#__PURE__*/React.createElement(Switch, {
    checked: true,
    onChange: () => {},
    size: "sm"
  }))))));
}
function AnalyticsScreen() {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 18,
      display: 'flex',
      flexDirection: 'column',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontSize: 22,
      color: 'var(--frost-100)'
    }
  }, "Analytics"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(HudPanel, {
    variant: "terminal",
    title: "Throughput",
    status: "req/s",
    accent: "cyan"
  }, /*#__PURE__*/React.createElement(NeonAreaChart, {
    id: "an1",
    data: [12, 18, 15, 28, 24, 33, 40, 38, 52, 60]
  })), /*#__PURE__*/React.createElement(HudPanel, {
    variant: "terminal",
    title: "Contracts Closed",
    status: "per hour",
    accent: "magenta"
  }, /*#__PURE__*/React.createElement(NeonBars, {
    data: [8, 14, 10, 20, 16, 24, 30, 22, 28, 34, 26, 40]
  }))), /*#__PURE__*/React.createElement(HudPanel, {
    variant: "terminal",
    title: "Node Latency",
    status: "ms \xB7 grid",
    accent: "mint"
  }, /*#__PURE__*/React.createElement(NeonAreaChart, {
    id: "an2",
    color: "var(--mint-500)",
    color2: "var(--cyan-500)",
    data: [60, 40, 52, 30, 44, 22, 33, 18, 26, 14, 20, 12]
  })));
}
const CONTRACTS = [{
  name: 'Corpse Alley',
  sub: '3 targets',
  tone: 'magenta'
}, {
  name: 'Sever the Link',
  sub: 'in progress',
  tone: 'cyan'
}, {
  name: 'Namo Thereni',
  sub: 'machine ghost',
  tone: 'cyan'
}, {
  name: 'Headers',
  sub: 'escort',
  tone: 'mint'
}, {
  name: 'Dog Inside',
  sub: 'malware breach',
  tone: 'magenta'
}, {
  name: 'Moongazed',
  sub: 'corpo intel',
  tone: 'violet'
}, {
  name: '321 Adexra ID',
  sub: 'phantom leak',
  tone: 'cyan'
}];
function TerminalScreen() {
  const [tab, setTab] = useState('decrypt');
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 18
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      marginBottom: 14
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontSize: 22,
      color: 'var(--frost-100)'
    }
  }, "Datastream"), /*#__PURE__*/React.createElement(Badge, {
    tone: "cyan"
  }, "DECRYPTING"), /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: 'auto',
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      color: 'var(--text-muted)',
      letterSpacing: '.1em'
    }
  }, "SESSION 16::4/2")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '240px 1fr 260px',
      gap: 12,
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement(HudPanel, {
    variant: "terminal",
    title: "Contracts",
    status: "ALL",
    accent: "magenta"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 4
    }
  }, CONTRACTS.map((c, i) => /*#__PURE__*/React.createElement("div", {
    key: c.name,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 9,
      padding: '7px 8px',
      background: i === 1 ? 'rgba(0,240,255,.08)' : 'transparent',
      borderLeft: i === 1 ? '2px solid var(--cyan-500)' : '2px solid transparent'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 7,
      height: 7,
      background: `var(--${c.tone}-500)`,
      boxShadow: `0 0 5px var(--${c.tone}-500)`,
      flexShrink: 0
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 12,
      color: i === 1 ? 'var(--cyan-400)' : 'var(--text-primary)',
      whiteSpace: 'nowrap',
      overflow: 'hidden',
      textOverflow: 'ellipsis'
    }
  }, c.name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 9,
      color: 'var(--text-muted)',
      letterSpacing: '.06em',
      textTransform: 'uppercase'
    }
  }, c.sub)))))), /*#__PURE__*/React.createElement(HudPanel, {
    variant: "terminal",
    title: "Retire :: Detention",
    status: "0x4F ++++",
    accent: "cyan",
    pulse: true
  }, /*#__PURE__*/React.createElement(Tabs, {
    tabs: [{
      value: 'decrypt',
      label: 'Decrypt'
    }, {
      value: 'archive',
      label: 'Archive'
    }, {
      value: 'trace',
      label: 'Trace'
    }],
    value: tab,
    onChange: setTab,
    style: {
      marginBottom: 12
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 12.5,
      lineHeight: 1.7,
      color: 'var(--text-secondary)'
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '0 0 12px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--cyan-400)'
    }
  }, ">"), " Safepointer boot sequence engaged. No handshake on the outer relay \u2014 routing through the cold node."), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '0 0 12px',
      color: 'var(--text-primary)'
    }
  }, "Payload full, gain one bit to sync the deck. The last runner ran the ghost line; the trace decays in ", /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--magenta-400)'
    }
  }, "94"), " cycles."), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '0 0 12px'
    }
  }, "Decrypting the station core: ", /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--mint-500)'
    }
  }, "OK"), " \xB7 fold the sigma keys to the firebridge and hold. Offer two vectors to the coprocessor before it locks."), /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--void-900)',
      border: '1px solid var(--border)',
      padding: '10px 12px',
      color: 'var(--mint-500)',
      fontSize: 11.5
    }
  }, /*#__PURE__*/React.createElement("div", null, "0x00 \xA0init cold-node \xA0", /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-muted)'
    }
  }, "done")), /*#__PURE__*/React.createElement("div", null, "0x01 \xA0spoof relay id \xA0", /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-muted)'
    }
  }, "done")), /*#__PURE__*/React.createElement("div", null, "0x02 \xA0inject sigma \xA0", /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--cyan-400)'
    }
  }, "running\u2026"), " ", /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--magenta-400)'
    }
  }, "\u2588\u2588\u2592\u2592"))))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(HudPanel, {
    variant: "terminal",
    title: "Plan Centre",
    status: "RUN",
    accent: "magenta"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      flexWrap: 'wrap',
      marginBottom: 12
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "sm",
    hud: true
  }, "Connect"), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "sm"
  }, "Exit")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 9,
      color: 'var(--mint-500)',
      letterSpacing: '.1em',
      marginBottom: 5
    }
  }, "SAFE"), /*#__PURE__*/React.createElement("div", {
    style: {
      border: '1px solid var(--border)'
    }
  }, /*#__PURE__*/React.createElement(Wireframe, {
    seed: 2,
    h: 92
  }))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 9,
      color: 'var(--magenta-400)',
      letterSpacing: '.1em',
      marginBottom: 5
    }
  }, "BETA"), /*#__PURE__*/React.createElement("div", {
    style: {
      border: '1px solid var(--border)'
    }
  }, /*#__PURE__*/React.createElement(Wireframe, {
    seed: 7,
    h: 92,
    color: "var(--magenta-500)"
  }))))), /*#__PURE__*/React.createElement(HudPanel, {
    variant: "terminal",
    title: "Balance",
    status: "NEG",
    accent: "mint"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      fontFamily: 'var(--font-mono)',
      fontSize: 13
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--mint-500)'
    }
  }, "\u20AC1,749"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 9,
      color: 'var(--text-muted)',
      letterSpacing: '.1em'
    }
  }, "EDDIES")), /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'right'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--magenta-400)'
    }
  }, "\u20AC420"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 9,
      color: 'var(--text-muted)',
      letterSpacing: '.1em'
    }
  }, "DEBT")))))));
}
function Placeholder({
  label,
  icon
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 18
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontSize: 22,
      color: 'var(--frost-100)',
      marginBottom: 14
    }
  }, label), /*#__PURE__*/React.createElement(HudPanel, {
    variant: "terminal",
    title: label,
    status: "NO SIGNAL",
    accent: "violet"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: 12,
      padding: '30px 0',
      color: 'var(--text-muted)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: icon,
    size: 40,
    color: "var(--void-200)"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 12,
      letterSpacing: '.1em'
    }
  }, "MODULE OFFLINE \u2014 reconnect to the grid."))));
}
function ConsoleApp() {
  const [logged, setLogged] = useState(false);
  const [active, setActive] = useState('overview');
  if (!logged) return /*#__PURE__*/React.createElement(LoginScreen, {
    onLogin: () => setLogged(true)
  });
  return /*#__PURE__*/React.createElement("div", {
    style: {
      height: '100%',
      display: 'flex',
      background: 'var(--void-900)'
    }
  }, /*#__PURE__*/React.createElement(Sidebar, {
    active: active,
    onNav: setActive
  }), /*#__PURE__*/React.createElement(CircuitFrame, null, /*#__PURE__*/React.createElement(TopBar, {
    onLogout: () => setLogged(false)
  }), /*#__PURE__*/React.createElement("main", {
    className: "nw-crt",
    style: {
      flex: 1,
      overflowY: 'auto',
      background: 'var(--bg-app)'
    }
  }, active === 'overview' && /*#__PURE__*/React.createElement(DashboardScreen, null), active === 'analytics' && /*#__PURE__*/React.createElement(AnalyticsScreen, null), active === 'datastream' && /*#__PURE__*/React.createElement(TerminalScreen, null), active === 'ice' && /*#__PURE__*/React.createElement(Placeholder, {
    label: "ICE",
    icon: "shield"
  }), active === 'messages' && /*#__PURE__*/React.createElement(Placeholder, {
    label: "Comms",
    icon: "message-square"
  }), active === 'settings' && /*#__PURE__*/React.createElement(Placeholder, {
    label: "Settings",
    icon: "settings"
  }))));
}
window.ConsoleApp = ConsoleApp;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/netrunner-console/app.jsx", error: String((e && e.message) || e) }); }

// ui_kits/netrunner-console/charts.jsx
try { (() => {
// NIGHTWIRE netrunner-console — neon SVG charts (self-contained, no deps).
// Exports NeonAreaChart, NeonBars, NeonDonut, Sparkline to window.

function polyPoints(data, w, h, pad) {
  const max = Math.max(...data) * 1.15 || 1;
  const min = Math.min(...data, 0);
  const span = max - min || 1;
  const step = (w - pad * 2) / (data.length - 1);
  return data.map((v, i) => [pad + i * step, h - pad - (v - min) / span * (h - pad * 2)]);
}
function NeonAreaChart({
  data = [],
  w = 560,
  h = 200,
  color = 'var(--cyan-500)',
  color2 = 'var(--magenta-500)',
  id = 'a'
}) {
  const pad = 16;
  const pts = polyPoints(data, w, h, pad);
  const line = pts.map(p => p.join(',')).join(' ');
  const area = `${line} ${w - pad},${h - pad} ${pad},${h - pad}`;
  return /*#__PURE__*/React.createElement("svg", {
    viewBox: `0 0 ${w} ${h}`,
    width: "100%",
    preserveAspectRatio: "none",
    style: {
      display: 'block'
    }
  }, /*#__PURE__*/React.createElement("defs", null, /*#__PURE__*/React.createElement("linearGradient", {
    id: `fill-${id}`,
    x1: "0",
    y1: "0",
    x2: "0",
    y2: "1"
  }, /*#__PURE__*/React.createElement("stop", {
    offset: "0%",
    stopColor: color,
    stopOpacity: "0.35"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: "100%",
    stopColor: color,
    stopOpacity: "0"
  })), /*#__PURE__*/React.createElement("linearGradient", {
    id: `stroke-${id}`,
    x1: "0",
    y1: "0",
    x2: "1",
    y2: "0"
  }, /*#__PURE__*/React.createElement("stop", {
    offset: "0%",
    stopColor: color
  }), /*#__PURE__*/React.createElement("stop", {
    offset: "100%",
    stopColor: color2
  }))), [0.25, 0.5, 0.75].map(f => /*#__PURE__*/React.createElement("line", {
    key: f,
    x1: pad,
    x2: w - pad,
    y1: pad + f * (h - pad * 2),
    y2: pad + f * (h - pad * 2),
    stroke: "rgba(137,155,180,.10)",
    strokeWidth: "1"
  })), /*#__PURE__*/React.createElement("polygon", {
    points: area,
    fill: `url(#fill-${id})`
  }), /*#__PURE__*/React.createElement("polyline", {
    points: line,
    fill: "none",
    stroke: `url(#stroke-${id})`,
    strokeWidth: "2.5",
    strokeLinejoin: "round",
    strokeLinecap: "round",
    style: {
      filter: 'drop-shadow(0 0 6px rgba(0,240,255,.5))'
    }
  }), pts.map((p, i) => i === pts.length - 1 && /*#__PURE__*/React.createElement("circle", {
    key: i,
    cx: p[0],
    cy: p[1],
    r: "4",
    fill: color2,
    style: {
      filter: 'drop-shadow(0 0 6px var(--magenta-500))'
    }
  })));
}
function NeonBars({
  data = [],
  w = 560,
  h = 200,
  color = 'var(--magenta-500)'
}) {
  const pad = 16;
  const max = Math.max(...data) * 1.1 || 1;
  const bw = (w - pad * 2) / data.length;
  return /*#__PURE__*/React.createElement("svg", {
    viewBox: `0 0 ${w} ${h}`,
    width: "100%",
    preserveAspectRatio: "none",
    style: {
      display: 'block'
    }
  }, data.map((v, i) => {
    const bh = v / max * (h - pad * 2);
    return /*#__PURE__*/React.createElement("rect", {
      key: i,
      x: pad + i * bw + bw * 0.18,
      y: h - pad - bh,
      width: bw * 0.64,
      height: bh,
      fill: color,
      opacity: 0.55 + 0.45 * (v / max),
      rx: "1",
      style: {
        filter: 'drop-shadow(0 0 4px rgba(255,45,149,.5))'
      }
    });
  }));
}
function NeonDonut({
  segments = [],
  size = 150,
  thickness = 18
}) {
  const r = (size - thickness) / 2;
  const c = 2 * Math.PI * r;
  const total = segments.reduce((s, x) => s + x.value, 0) || 1;
  let offset = 0;
  return /*#__PURE__*/React.createElement("svg", {
    viewBox: `0 0 ${size} ${size}`,
    width: size,
    height: size
  }, /*#__PURE__*/React.createElement("circle", {
    cx: size / 2,
    cy: size / 2,
    r: r,
    fill: "none",
    stroke: "var(--void-500)",
    strokeWidth: thickness
  }), segments.map((s, i) => {
    const len = s.value / total * c;
    const el = /*#__PURE__*/React.createElement("circle", {
      key: i,
      cx: size / 2,
      cy: size / 2,
      r: r,
      fill: "none",
      stroke: s.color,
      strokeWidth: thickness,
      strokeDasharray: `${len} ${c - len}`,
      strokeDashoffset: -offset,
      transform: `rotate(-90 ${size / 2} ${size / 2})`,
      style: {
        filter: `drop-shadow(0 0 4px ${s.color})`
      }
    });
    offset += len;
    return el;
  }));
}
function Sparkline({
  data = [],
  w = 90,
  h = 28,
  color = 'var(--mint-500)'
}) {
  const pts = polyPoints(data, w, h, 3).map(p => p.join(',')).join(' ');
  return /*#__PURE__*/React.createElement("svg", {
    viewBox: `0 0 ${w} ${h}`,
    width: w,
    height: h
  }, /*#__PURE__*/React.createElement("polyline", {
    points: pts,
    fill: "none",
    stroke: color,
    strokeWidth: "1.5",
    strokeLinejoin: "round"
  }));
}

// Cyan wireframe diagram (ref #4 "safe/beta" boxes) — grid + random node graph.
function Wireframe({
  w = 180,
  h = 120,
  color = 'var(--cyan-500)',
  seed = 1
}) {
  const rand = n => {
    let x = Math.sin(seed * 999 + n * 37) * 10000;
    return x - Math.floor(x);
  };
  const nodes = Array.from({
    length: 7
  }, (_, i) => [12 + rand(i) * (w - 24), 12 + rand(i + 20) * (h - 24)]);
  const edges = [[0, 1], [1, 2], [2, 3], [0, 4], [4, 5], [5, 6], [3, 6], [1, 5]];
  return /*#__PURE__*/React.createElement("svg", {
    viewBox: `0 0 ${w} ${h}`,
    width: "100%",
    style: {
      display: 'block'
    }
  }, /*#__PURE__*/React.createElement("defs", null, /*#__PURE__*/React.createElement("pattern", {
    id: `wg${seed}`,
    width: "14",
    height: "14",
    patternUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M14 0H0V14",
    fill: "none",
    stroke: "rgba(0,240,255,.10)",
    strokeWidth: "1"
  }))), /*#__PURE__*/React.createElement("rect", {
    x: "0",
    y: "0",
    width: w,
    height: h,
    fill: `url(#wg${seed})`
  }), edges.map((e, i) => /*#__PURE__*/React.createElement("line", {
    key: i,
    x1: nodes[e[0]][0],
    y1: nodes[e[0]][1],
    x2: nodes[e[1]][0],
    y2: nodes[e[1]][1],
    stroke: color,
    strokeWidth: "1",
    opacity: ".7"
  })), nodes.map((n, i) => /*#__PURE__*/React.createElement("circle", {
    key: i,
    cx: n[0],
    cy: n[1],
    r: i === 0 ? 4 : 2.5,
    fill: color,
    style: {
      filter: 'drop-shadow(0 0 4px var(--cyan-500))'
    }
  })));
}
Object.assign(window, {
  NeonAreaChart,
  NeonBars,
  NeonDonut,
  Sparkline,
  Wireframe
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/netrunner-console/charts.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Avatar = __ds_scope.Avatar;

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.Alert = __ds_scope.Alert;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.ProgressBar = __ds_scope.ProgressBar;

__ds_ns.Tag = __ds_scope.Tag;

__ds_ns.Toast = __ds_scope.Toast;

__ds_ns.Tooltip = __ds_scope.Tooltip;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Radio = __ds_scope.Radio;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Slider = __ds_scope.Slider;

__ds_ns.Switch = __ds_scope.Switch;

__ds_ns.Breadcrumbs = __ds_scope.Breadcrumbs;

__ds_ns.CommandPalette = __ds_scope.CommandPalette;

__ds_ns.Pagination = __ds_scope.Pagination;

__ds_ns.Tabs = __ds_scope.Tabs;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.DataTable = __ds_scope.DataTable;

__ds_ns.HudPanel = __ds_scope.HudPanel;

__ds_ns.StatCard = __ds_scope.StatCard;

})();
